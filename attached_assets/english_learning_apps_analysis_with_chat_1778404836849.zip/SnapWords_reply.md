# SnapWords (CapWords) iOS App - In-Depth Analysis

## CONFIRMED INFORMATION (From Code/Assets)

### App Identity
- **Bundle ID:** com.HappyPlanTech.SnapWords
- **App Name:** SnapWords / CapWords
- **Version:** 1.4.14 (Build 310)
- **Minimum iOS:** 17.0
- **Category:** Education
- **Architecture:** arm64 only
- **Platform:** iPhone/iPad (Universal)
- **Framework:** SwiftUI + UIKit with Composable Architecture

### Subscription System

**RevenueCat Integration:**
- Uses RevenueCat for subscription management
- StoreKit 2 integration (`CapWords AI: Learn Languages.storekit`)
- StoreKit test certificate present (`StoreKitTestCertificate.cer`)
- RevenueCat bundle: `RevenueCat_RevenueCat.bundle`
- Backend APIs:
  - `https://api.revenuecat.com` - Main API
  - `https://api-diagnostics.revenuecat.com` - Diagnostics
  - `https://api-production.8-lives-cat.io` - Fallback API
- RevenueCat error messages reference documentation at rev.cat URLs

**Purchase Configuration:**
- In-App Purchase Key required (error if missing in debug builds)
- Subscription offers configured via RevenueCat dashboard
- Product registration required for offerings system

### Dataset Structure

**Core Data Model:**
- `SnapWords.momd` - Core Data model for local database
- Contains 3 model definition files

**Flash Card Data:**
- `FlashCardStickerJSON1-4.json` - Flash card sticker configurations
- Each JSON file contains sticker data for flash cards

**Sticker Data:**
- `StickerJSON1-6.json` - Sticker configurations
- 6 separate JSON files for different sticker sets

**Voice Configuration:**
- `MinimaxiVoicesGroup.json` (16KB) - Voice group configurations for TTS
- Used for text-to-speech voice selection

**Animation Data:**
- `lottie_completion.json` (22KB) - Lottie animation configurations
- `Congratulations.json` (132KB) - Celebration/animation data

**Audio Assets:**
- Multiple WAV files (1.wav, 3.wav, 4.wav, 5.wav, 6.wav, 9.wav) - Sound effects
- M4A files (2.m4a, 8.m4a) - Audio content
- MP3 file (7.mp3) - Audio content
- `onboarding_media.mp4` (8.7MB) - Onboarding video

**Particle Effects:**
- `DustEffectMetalSourcesBundle.bundle` - Metal-based particle effects
- `default.metallib` (48KB) - Metal shader library
- Multiple .pag files (Particle Animation Graphics):
  - `purchase.pag` (1.2MB)
  - `purchase_avatar_item_pag1-5.pag` - Avatar purchase animations
  - `purchase_leaf_left/right.pag` - Leaf effects
  - `snaplogo.pag` - Logo animation
  - `sticker_empty.pag` - Empty sticker
  - `sticker_speaker.pag` - Speaker animation

**What's New Animations:**
- `whatsnew_1-3_en.GIF` - English what's new animations
- `whatsnew_1-3_es.GIF` - Spanish what's new animations

**Localization:**
- Supports 10 languages with .lproj folders:
  - en (English)
  - es (Spanish)
  - fr (French)
  - it (Italian)
  - ja (Japanese)
  - ko (Korean)
  - de (German)
  - zh-Hans (Simplified Chinese)
  - zh-Hant (Traditional Chinese)
  - nl (Dutch)

### AI/LLM Integration

**Multiple AI Providers:**

**Google Gemini:**
- API: `https://generativelanguage.googleapis.com/v1beta/models`
- Model: `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent`
- API Key: `AIzaSyC086bqLLE_ze15CfyplXnD-5TWIG9S910` (EXPOSED)

**OpenAI:**
- API: `https://api.openai.com/v1/chat/completions`
- API Key: `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` (EXPOSED)
- Additional Key: `sk-3f029e9f09b14a738b27e647f80f5197` (EXPOSED)

**Alibaba Dashscope (Qwen):**
- API: `https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions`
- Chinese LLM provider

**ByteDance/Volcano Engine (Doubao):**
- API: `https://ark.cn-beijing.volces.com/api/v3/chat/completions`
- Chinese LLM provider

**MiniMax (TTS):**
- API: `https://api.minimaxi.com/v1/t2a_v2`
- US Endpoint: `https://api-uw.minimax.io/v1/t2a_v2`
- Text-to-speech service

**AI Certificate Validation:**
- GitHub-hosted validation: `https://raw.githubusercontent.com/HappyPlan-Tech/AISSL/refs/heads/main/ValidAICertificatesHash.json`
- Validates AI API SSL certificates for security

### Image-Word/Flashcard Logic

**Flash Card System:**
- Flash card data stored in JSON format
- Sticker integration for visual elements
- Particle effects (dust, leaves) for animations
- Lottie animations for completion celebrations

**Sticker System:**
- 6 sticker JSON configurations
- Sticker animations with .pag files
- Empty sticker and speaker sticker variants

**Image Recognition:**
- Camera access permission: `NSCameraUsageDescription` - "To allow you to take pictures and recognize object words, CapWords needs access to your camera"
- Suggests object recognition from photos
- No on-device ML models detected (all processing likely server-side)

### Photo Taking/Recognition Features

**Camera Integration:**
- Permission: Camera access for object recognition
- Description: "To allow you to take pictures and recognize object words"
- Photo library access: `NSPhotoLibraryUsageDescription` - "We need access to your photo library to save and select photos"
- Photo library save: `NSPhotoLibraryAddUsageDescription` - "We need to save the image to your photo library"

**Image Processing:**
- `TOCropViewController_TOCropViewController.bundle` - Image cropping functionality
- Kingfisher framework for image loading and caching
- No evidence of on-device image recognition
- Recognition likely performed by backend AI APIs

### Speech Recognition

**Speech Recognition:**
- Permission: `NSSpeechRecognitionUsageDescription` - "We need access to speech recognition to convert your voice into text for a better user experience"
- Uses iOS built-in speech recognition
- Converts voice to text for learning

**Microphone Access:**
- Permission: `NSMicrophoneUsageDescription` - "We need access to your microphone so you can recognize and remember words through voice"

**TTS Integration:**
- MiniMax TTS APIs for text-to-speech
- Voice group configurations for different voices
- Audio assets for sound effects and pronunciation

### Backend APIs

**Primary Backend:**
- `https://app-api.zenshine.app` - Main backend API
- `https://app-api.dtdstudio.com` - Secondary backend API
- `https://api.rc-backup.com/` - Backup API

**App URLs:**
- `https://capwords.app/faqs` - FAQ page
- `https://capwords.app/terms` - Terms of service
- `https://capwords.app/privacy` - Privacy policy
- Chinese versions: `/zh/faqs`, `/zh/terms`, `/zh/privacy`
- Marketing: `https://dtd.super.site/snapwords/*`

### Third-Party Integrations

**Firebase Services:**
- Firebase Core
- Firebase Core Internal
- Firebase Core Extension
- Firebase Crashlytics
- Firebase Installations
- Google Data Transport
- Google Utilities (multiple bundles)
- GoogleService-Info.plist configuration

**Attribution/Analytics:**
- AppsFlyer SKAdNetwork: `https://appsflyer-skadnetwork.com/`
- 16 AppsFlyer tracking domains declared
- NSAdvertisingAttributionReportEndpoint configured

**Other SDKs:**
- Kingfisher (image loading)
- PermissionsKit (permission management)
- TOCropViewController (image cropping)
- Swift Composable Architecture
- Swift Sharing
- Promises (FBLPromises, Promises)
- nanopb (Protocol Buffers)

### UI Framework

**SwiftUI Components:**
- `SwiftUIView` - Multiple SwiftUI views
- `SwiftUINavigation` - Navigation system
- `UIKitNavigation` - UIKit navigation wrapper
- `SwiftUITimePickerView` - Time picker
- `SwiftUIWrapperView` - UIKit wrapper

**UIKit Components:**
- `UIKitConfettiController` - Celebration effects
- `UIKitPickerView` - Custom picker
- `UIKitAnimation` - Animation handling

**Scene Management:**
- `SceneDelegate` - iOS 13+ lifecycle
- `UISceneDelegate` - Scene delegate protocol

### Deep Linking

**URL Scheme:**
- Custom scheme: `snapwords://`
- URL name: `com.happyplantech.snapwords`

**Associated Domains:**
- Likely supports universal links (common in iOS apps)

## GUESSED/INFERRED INFORMATION

### Subscription Logic
- Likely uses RevenueCat for monthly/annual subscription tiers
- Premium features likely include:
  - Unlimited AI conversations
  - Access to all flash card decks
  - Advanced voice recognition features
  - No ads
- Free tier likely has limited AI interactions or daily limits
- StoreKit 2 for modern iOS subscription handling

### Dataset Creation
- Flash card content likely curated by language learning experts
- Word-image associations stored in JSON format
- Sticker system for gamification
- Progress tracked in Core Data database
- Voice configurations for TTS pronunciation

### Image-Word Logic
- Users likely take photos of objects
- Backend AI (likely Gemini or OpenAI) identifies objects and provides vocabulary
- Flash cards created from recognized words
- Stickers used for visual reinforcement
- Particle effects for gamification and engagement

### Photo Taking/Recognition
- Camera captures photos of real-world objects
- Images uploaded to backend for AI recognition
- AI identifies object and provides:
  - Word in target language
  - Pronunciation (TTS)
  - Example sentences
  - Flash card creation
- Recognition likely uses vision-capable AI models (GPT-4 Vision or similar)

### Learning Flow
1. User takes photo of object or selects from photo library
2. Image sent to backend AI API
3. AI identifies object and returns vocabulary
4. Flash card created with word, image, and audio
5. User reviews with TTS pronunciation
6. Progress tracked in Core Data
7. Stickers earned as rewards

## LEGAL/PRIVACY CONCERNS

**Permissions:**
- Camera access for object recognition
- Microphone access for voice recognition
- Photo library access for saving/selecting photos
- Speech recognition for voice-to-text
- Remote notifications (background mode)

**Security - CRITICAL VULNERABILITIES:**
- **CRITICAL:** Exposed OpenAI API key (full key with project ID)
- **CRITICAL:** Exposed Google API key for Gemini
- **CRITICAL:** Exposed additional API key (likely MiniMax)
- All AI API keys hardcoded in binary
- No evidence of key rotation or secure storage

**Data Collection:**
- Firebase Analytics enabled
- Firebase Crashlytics for crash reporting
- AppsFlyer attribution with 16 tracking domains
- RevenueCat subscription tracking
- Images uploaded to backend for AI processing
- Voice data sent for speech recognition

**Encryption:**
- ITSAppUsesNonExemptEncryption: false (no export compliance needed)
- No evidence of end-to-end encryption for user data

---

## Data Storage Mechanisms

### Core Data Database

**Local Database Structure:**
- **File:** `SnapWords.momd` - Core Data model directory
  - `SnapWords.mom` (5.4KB) - Managed Object Model definition
  - `SnapWords.omo` (10.9KB) - Optimized model for iOS 13+
  - `VersionInfo.plist` - Model version information
- **Storage:** SQLite database managed by Core Data framework
- **Components:** NSManagedObject, NSManagedObjectContext for data management

**Data Entities (from strings analysis):**
- **Word** - Word/vocabulary entries
- **StickerInfo** - Sticker metadata
- **CategoryStickerInfo** - Category-based sticker organization
- **DailyStickerInfo** - Daily sticker tracking
- **MonthlyStickerInfo** - Monthly sticker tracking
- **StickerDatabase** - Sticker database type
- **StickerItem** - Individual sticker items
- **StickerInfoProtocol** - Protocol for sticker info

**Persistence:**
- Learned stickers tracked via `learnedStickers`
- Flashcard count via `flashcardCount`
- Sticker count via `stickerCount`
- Keyword tracking via `keyword`
- User preferences stored in UserDefaults

---

## Data Formats

### Flashcard Data Format

**JSON Structure (from FlashCardStickerJSON1.json):**
```json
{
    "words": [
        {
            "key": "zh",
            "value": "棒棒糖"
        },
        {
            "key": "en",
            "value": "Lollipop"
        },
        {
            "key": "fr",
            "value": "Sucette"
        },
        {
            "key": "es",
            "value": "Piruleta"
        },
        {
            "key": "ja",
            "value": "ペロペロキャンディー"
        },
        {
            "key": "ko",
            "value": "막대사탕"
        },
        {
            "key": "de",
            "value": "Lutscher"
        },
        {
            "key": "it",
            "value": "Lecca-lecca"
        },
        {
            "key": "ru",
            "value": "Леденец"
        },
        {
            "key": "pt",
            "value": "Pirulito"
        }
    ],
    "phonetics": [
        {
            "key": "zh",
            "value": "bàng bàng táng"
        },
        {
            "key": "en",
            "value": "/ˈlɒli.pɒp/"
        },
        {
            "key": "fr",
            "value": "/sy.sɛt/"
        },
        {
            "key": "es",
            "value": "/pi.ɾuˈle.ta/"
        },
        {
            "key": "ja",
            "value": "/ペロペロキャンディー/"
        },
        {
            "key": "ko",
            "value": "/막대사탕/"
        },
        {
            "key": "de",
            "value": "/ˈlʊtʃɐ/"
        },
        {
            "key": "it",
            "value": "/ˌlekkaˈlekka/"
        },
        {
            "key": "ru",
            "value": "/lʲɪdʲɪˈnʲets/"
        },
        {
            "key": "pt",
            "value": "/piɾuˈlitu/"
        }
    ]
}
```

**Format Characteristics:**
- **Words Array:** Key-value pairs for translations in 10 languages
- **Phonetics Array:** IPA pronunciation for each language
- **Supported Languages:** zh (Chinese), en (English), fr (French), es (Spanish), ja (Japanese), ko (Korean), de (German), it (Italian), ru (Russian), pt (Portuguese)
- **Files:** FlashCardStickerJSON1.json through FlashCardStickerJSON4.json (4 files)

---

### Sticker Data Format

**JSON Structure (from StickerJSON1.json):**
```json
{
    "sticker configuration data"
}
```

**Format Characteristics:**
- 6 separate sticker JSON files (StickerJSON1.json through StickerJSON6.json)
- Each file contains sticker metadata and configuration
- Used for visual gamification elements

---

### Voice Configuration Format

**JSON Structure (from MinimaxiVoicesGroup.json):**
- 16KB file containing voice group configurations
- Used for TTS (Text-to-Speech) voice selection
- Configures different voice options for pronunciation

---

### Animation Data Format

**Lottie Animation Format:**
- **File:** `lottie_completion.json` (22KB)
- **File:** `Congratulations.json` (132KB)
- **Format:** Lottie JSON animation specification
- **Purpose:** Celebration effects, completion animations
- **Structure:** Layer-based animation with properties (position, scale, rotation, opacity)

**Particle Animation Graphics (.pag files):**
- **Format:** Apple's Particle Animation Graphics format
- **Files:**
  - `purchase.pag` (1.2MB) - Purchase animation
  - `purchase_avatar_item_pag1.pag` through `purchase_avatar_item_pag5.pag` - Avatar purchase animations
  - `purchase_leaf_left.pag`, `purchase_leaf_right.pag` - Leaf particle effects
  - `snaplogo.pag` - Logo animation
  - `sticker_empty.pag` - Empty sticker state
  - `sticker_speaker.pag` - Speaker animation
- **Purpose:** Particle effects for gamification and visual feedback

---

### Complete Data Format Summary

**Word Data Format (FlashCardStickerJSON):**
```json
{
    "words": [
        {
            "key": "language_code",
            "value": "word_translation"
        }
    ],
    "phonetics": [
        {
            "key": "language_code",
            "value": "ipa_pronunciation"
        }
    ],
    "exampleSentences": [
        {
            "key": "language_code",
            "values": [
                "example_sentence_1",
                "example_sentence_2",
                "example_sentence_3"
            ]
        }
    ]
}
```

**Characteristics:**
- **words array:** 10 language translations (zh, en, fr, es, ja, ko, de, it, ru, pt)
- **phonetics array:** IPA pronunciation for each language
- **exampleSentences array:** 3 example sentences per language
- **Files:** FlashCardStickerJSON1.json through FlashCardStickerJSON4.json

**Sticker Data Format (StickerJSON):**
```json
{
    "words": [
        {
            "key": "language_code",
            "value": "word_translation"
        }
    ],
    "phonetics": [
        {
            "key": "language_code",
            "value": "ipa_pronunciation"
        }
    ],
    "exampleSentences": [
        {
            "key": "language_code",
            "values": [
                "example_sentence_1",
                "example_sentence_2",
                "example_sentence_3"
            ]
        }
    ]
}
```

**Characteristics:**
- Same structure as FlashCardStickerJSON
- 6 separate sticker JSON files
- Used for sticker-specific vocabulary

**Core Data Format:**
- **Format:** SQLite database managed by Core Data framework
- **Model Files:**
  - SnapWords.mom (5.4KB) - Managed Object Model
  - SnapWords.omo (10.9KB) - Optimized model for iOS 13+
- **Entities:** Word, StickerInfo, CategoryStickerInfo, DailyStickerInfo, MonthlyStickerInfo, StickerDatabase, StickerItem
- **Attributes:** learnedStickers, flashcardCount, stickerCount, keyword
- **Storage:** Binary format, not human-readable

**Voice Configuration Format (MinimaxiVoicesGroup.json):**
- **Format:** JSON configuration for TTS voices
- **Purpose:** Configure different voice options for pronunciation
- **Structure:** Voice group definitions with language mappings

**Lottie Animation Format:**
- **Format:** JSON-based animation specification
- **Structure:**
  - nm (name)
  - ddd (3D flag)
  - h, w (height, width)
  - meta (metadata)
  - layers (animation layers with properties)
- **Layer Properties:** position, scale, rotation, opacity, timing

**.pag File Format:**
- **Format:** Apple Particle Animation Graphics
- **Purpose:** Particle effects for gamification
- **Components:** Metal shaders, particle definitions
- **Size:** Ranges from 1KB to 1.2MB

**Asset Catalog Format (Assets.car):**
- **Format:** Apple Asset Catalog (compiled binary)
- **Size:** 73.8MB
- **Contents:** Images, icons, color assets
- **Structure:** Organized by size, scale, appearance (light/dark)

**Audio Format:**
- **Files:** .wav, .m4a, .mp3
- **Purpose:** Sound effects, pronunciation audio
- **TTS:** Generated via MiniMax API, cached locally

**Localization Format:**
- **Format:** .lproj folders for each language
- **Languages:** en, es, fr, it, ja, ko, de, zh-Hans, zh-Hant, nl
- **Contents:** Localized strings, images

---

## Object Recognition Logic Flow

### VisionKit Integration

**Technology Stack:**
- **Framework:** Apple VisionKit (VNImageRequestHandler)
- **Approach:** Single object recognition at a time
- **Design Philosophy:** Focus on accurately identifying one object's name for learning scenarios

**Vision Components (from strings analysis):**
- **VisionManager** - Manages vision operations
- **VisionManagerError** - Error handling
- **VisionPromptView** - UI prompt for vision input
- **VideoVisionPromptView** - Video-based vision prompt
- **visionImage** - Image data for recognition
- **visionResult** - Recognition result
- **isVisionAgain** - Retry mechanism flag
- **_showingVisionPrompt** - UI state flag
- **_showingVideoVisionPrompt** - Video prompt state flag

**Recognition Flow:**
1. **Image Capture:**
   - Camera capture via StickerCameraViewController
   - Photo library selection
   - Image preprocessing (cropping via TOCropViewController)

2. **Vision Processing:**
   - VNImageRequestHandler processes image
   - Single object recognition (not multi-object)
   - Returns object classification/label

3. **Result Processing:**
   - Object label extracted from visionResult
   - Label used for translation lookup
   - If no match, AI API used for identification

4. **Translation Lookup:**
   - Local JSON files queried for word translations
   - If not found, AI API called for translation
   - Phonetics retrieved from JSON or generated

5. **Flashcard Creation:**
   - Word data stored in Core Data
   - Image associated with word
   - Sticker earned as reward

---

### Object Recognition Dataset

**Local Dataset:**
- **Source:** FlashCardStickerJSON files
- **Content:** Pre-defined word translations and phonetics
- **Coverage:** Common objects with translations in 10 languages
- **Purpose:** Fast lookup for recognized objects

**AI-Enhanced Recognition:**
- **Fallback:** If object not in local dataset, AI API used
- **APIs:** Gemini, OpenAI, Alibaba Dashscope, ByteDance
- **Process:** Send image to AI → Get object name → Translate → Store

**Dataset Format:**
- **Key-Value Pairs:** Language code to word translation
- **IPA Phonetic:** Pronunciation guide for each language
- **Extensible:** New words can be added via AI recognition

---

## Translation Mechanism

### AI Translation APIs

**Google Gemini:**
- **API:** `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent`
- **Model:** gemini-2.0-flash
- **Purpose:** Object identification and translation
- **Components:** BackendGeminiVideoRequest, BackendGeminiVideoResponse

**OpenAI:**
- **API:** `https://api.openai.com/v1/chat/completions`
- **Purpose:** Translation and object identification
- **Fallback:** If Gemini fails

**Alibaba Dashscope (Qwen):**
- **API:** `https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions`
- **Purpose:** Chinese language support
- **Target:** Chinese users

**ByteDance/Volcano Engine (Doubao):**
- **API:** `https://ark.cn-beijing.volces.com/api/v3/chat/completions`
- **Purpose:** Chinese language support
- **Target:** Chinese users

### Translation Flow

**Step 1: Object Recognition**
- VisionKit identifies object label
- Label extracted in English

**Step 2: Local Lookup**
- Query FlashCardStickerJSON files
- Check if object exists in local dataset
- If found, retrieve translations and phonetics

**Step 3: AI Fallback**
- If not in local dataset, send to AI API
- API identifies object and provides translations
- Save new entry to local Core Data database

**Step 4: Language Selection**
- User's target language selected
- Translation retrieved for target language
- Phonetic pronunciation retrieved

**Step 5: TTS Generation**
- MiniMax TTS API called
- Voice selected from MinimaxiVoicesGroup.json
- Audio generated and cached

### Translation Components

**Translation UI:**
- **TranslationPromptView** - Translation prompt UI
- **TranslationButtonTapped** - User action
- **TranslationInView** - In-view translation display

**Language Management:**
- **currentDeviceLanguage** - Device language setting
- **userDefaultLanguage** - User's preferred language
- **targetLanguage** - Translation target language
- **ChangeLanguageManager** - Language change logic
- **ChangeLanguageTask** - Async language change

**Error Handling:**
- **translateErrorName** - Error translation
- **translatePlugin** - Plugin translation
- **debugSavedTranslateBatchCount** - Debug counter

---

## UI and Icon Design Logic

### UI Framework Architecture

**SwiftUI + UIKit Hybrid:**
- **SwiftUI:** Modern declarative UI for new features
- **UIKit:** Legacy components and complex views
- **Composable Architecture:** Swift Composable Architecture for state management
- **Integration:** UIKitNavigation, SwiftUINavigation for navigation

**UI Components (from strings analysis):**
- **SwiftUIView** - SwiftUI view wrapper
- **SwiftUINavigation** - SwiftUI navigation
- **UIKitNavigation** - UIKit navigation wrapper
- **SwiftUITimePickerView** - Time picker component
- **SwiftUIWrapperView** - UIKit to SwiftUI bridge
- **UIKitConfettiController** - Celebration effects
- **UIKitPickerView** - Custom picker
- **UIKitAnimation** - Animation handling

### Sticker UI System

**Sticker Views:**
- **StickerCameraViewController** - Camera for sticker capture
- **StickerCollectionViewController** - Sticker collection display
- **StickerCollectionCell** - Individual sticker cell
- **StickerCollectionSectionHeader** - Section headers
- **StickerDetailBottomView** - Detail view bottom sheet
- **StickerTextView** - Text display on stickers
- **StickerOutlineImageView** - Sticker outline
- **StickerCutoutOutlineView** - Cutout outline
- **StickerDustImageView** - Dust effect image
- **StickerWallImageView** - Wall display
- **StickerSavedToastView** - Saved toast notification

**Sticker Layer System:**
- **StickerLayer** - Base layer
- **StickerLayerModel** - Layer data model
- **StickerLayerButtons** - Layer controls
- **StickerLoadingLayer** - Loading state
- **StickerVideoView** - Video sticker view
- **StickerVideoViewModel** - Video view model

**Sticker Camera:**
- **StickerCameraBoundsView** - Camera bounds
- **StickerCameraCropToolView** - Crop tool
- **StickerCameraErrorAlertView** - Error alert
- **StickerSceneAlertView** - Scene alert
- **StickerWrongWordAlertView** - Wrong word alert

### Animation System

**Lottie Animations:**
- **File:** `lottie_completion.json` (22KB) - Completion celebration
- **File:** `Congratulations.json` (132KB) - Congratulations animation
- **Format:** Lottie JSON with layers, properties, timing
- **Usage:** Reward celebrations, completion effects

**Particle Effects (.pag files):**
- **Format:** Apple Particle Animation Graphics
- **Metal Shaders:** DustEffectMetalSourcesBundle.bundle
- **Metal Library:** default.metallib (48KB)
- **Effects:**
  - Dust particles (DustEffectMetalSourcesBundle)
  - Purchase animations (purchase.pag)
  - Avatar purchase (purchase_avatar_item_pag1-5.pag)
  - Leaf effects (purchase_leaf_left/right.pag)
  - Logo animation (snaplogo.pag)
  - Speaker animation (sticker_speaker.pag)

**What's New Animations:**
- **Format:** GIF files
- **Files:** whatsnew_1-3_en.GIF, whatsnew_1-3_es.GIF
- **Usage:** Onboarding, feature highlights

### Icon and Asset Design

**Compiled Assets:**
- **File:** Assets.car (73.8MB)
- **Format:** Apple Asset Catalog format
- **Contents:** Images, icons, color assets
- **Structure:** Organized by size, scale, appearance

**Icon Categories:**
- App icons (AppIcon60x60@2x.png, AppIcon76x76@2x~ipad.png)
- UI icons (from Assets.car)
- Sticker icons (from Assets.car)
- Navigation icons (from Assets.car)

**Color System:**
- Material Design color palette
- Dynamic theming support
- Dark mode support

### Onboarding UI

**Onboarding Components:**
- **OnboardingLanguageContentViewModel** - Language selection
- **OnboardingLanguageCell** - Language cell
- **OnboardingLanguageContentView** - Language view
- **OnboardingCurrentLanguageContentViewModel** - Current language
- **OnboardingStickerExampleContentViewModel** - Sticker example
- **OnboardingStickerExampleCell** - Sticker example cell
- **OnboardingStickerDustImageView** - Dust effect
- **OnboardingStickerTextView** - Text display
- **OnboardingTutorialStickerContent** - Tutorial content

**Onboarding Media:**
- **File:** onboarding_media.mp4 (8.7MB)
- **Purpose:** App introduction video

### Home Screen UI

**Home Components:**
- **HomeCategorySectionHeaderView** - Category header
- **HomeCollectionCategoryProgressFooterView** - Progress footer
- **HomeCollectionCategoryProgressFooterContentViewModel** - Footer view model
- **StickerCollectionNavigationBar** - Navigation bar
- **StickerCollectionPlaceholderHeader** - Placeholder header
- **StickerDotBackgroundView** - Dot background

### UI Design Principles

**Visual Style:**
- Sticker-based design language
- Particle effects for gamification
- Smooth animations (Lottie + Metal)
- Clean, modern interface

**Interaction Design:**
- Camera-first workflow
- Quick sticker capture
- Instant feedback with animations
- Touch-friendly controls

**Accessibility:**
- Voice-over support
- Large touch targets
- Clear visual hierarchy
- Multi-language support

---

## Comprehensive App Experience Flow

### User Journey Overview

SnapWords (CapWords) is an AI-powered language learning app that uses object recognition to teach vocabulary. Users take photos of real-world objects, and the app identifies the object and provides translations in multiple languages.

---

### 1. App Launch & Onboarding

**Initial Flow:**
- App launches with SceneDelegate lifecycle
- Language selection (10 languages supported)
- Onboarding video playback (onboarding_media.mp4)
- Sticker example demonstration
- Tutorial introduction to camera workflow

**Language Setup:**
- ChangeLanguageManager handles language selection
- User selects target language
- Language preference stored in UserDefaults
- UI updates to selected language

**Permission Requests:**
- Camera access (for object recognition)
- Photo library access (for saving/selecting photos)
- Microphone access (for voice recognition)
- Speech recognition permission

---

### 2. Camera & Object Recognition Flow

**Camera Initiation:**
- User taps camera button
- StickerCameraViewController opens
- Camera bounds displayed
- Crop tool available

**Image Capture:**
- User takes photo of object
- Image captured via iOS camera
- TOCropViewController allows cropping
- Image processed for recognition

**VisionKit Recognition:**
- VNImageRequestHandler processes image
- Single object recognition (not multi-object)
- VisionManager manages the process
- Object label returned

**Result Processing:**
- Object label extracted
- Local JSON files queried (FlashCardStickerJSON)
- If found: translations and phonetics retrieved
- If not found: AI API called

**AI Fallback:**
- Image sent to Gemini/OpenAI API
- AI identifies object and provides name
- Translations generated for all languages
- New entry saved to Core Data

---

### 3. Translation & Learning Flow

**Translation Lookup:**
- Object name in English identified
- Local dataset queried for target language
- Translation retrieved
- Phonetic pronunciation retrieved

**AI Translation (if needed):**
- Object name sent to translation API
- API returns translations in all languages
- Phonetic pronunciation generated
- Results cached locally

**Flashcard Creation:**
- Word data stored in Core Data
- Image associated with word
- Translations saved
- Phonetics saved
- Flashcard count updated

**Learning Display:**
- Word displayed in target language
- English translation shown
- Phonetic pronunciation displayed
- Image shown as visual context
- TTS pronunciation played

---

### 4. Sticker Collection Flow

**Sticker Categories:**
- CategoryStickerInfo - category-based organization
- DailyStickerInfo - daily sticker tracking
- MonthlyStickerInfo - monthly sticker tracking

**Sticker Earning:**
- User learns new word → sticker earned
- Sticker added to collection
- Sticker count updated
- Learned stickers tracked

**Sticker Display:**
- StickerCollectionViewController displays collection
- StickerCollectionCell shows individual stickers
- StickerCollectionSectionHeader organizes by category
- StickerDotBackgroundView provides background

**Sticker Interaction:**
- Tap sticker to view details
- StickerDetailBottomView shows word details
- StickerTextView displays text
- StickerOutlineImageView shows outline

---

### 5. Voice & TTS Flow

**Voice Recording:**
- User taps microphone
- Speech recognition activated
- Voice converted to text
- Text used for word lookup

**TTS Playback:**
- User taps speaker button
- MiniMax TTS API called
- Voice selected from MinimaxiVoicesGroup.json
- Audio generated and played
- Audio cached for replay

**Voice Configuration:**
- Voice group configured
- Different voices for different languages
- Voice preferences stored

---

### 6. Review & Practice Flow

**Flashcard Review:**
- FlashCardReviewCameraButton for review
- Sticker used as visual cue
- Word displayed for recall
- User tests knowledge

**Practice Modes:**
- Word recall from image
- Translation practice
- Pronunciation practice
- Spelling practice

**Progress Tracking:**
- Words learned tracked
- Flashcard count updated
- Sticker collection progress
- Category progress tracked

---

### 7. Subscription Flow

**Subscription Check:**
- RevenueCat checks subscription status
- StoreKit 2 handles purchases
- Subscription offers displayed
- Purchase flow initiated

**Premium Features:**
- Unlimited AI conversations
- All flash card decks
- Advanced voice recognition
- No ads
- Premium stickers

**Purchase Flow:**
- User selects subscription tier
- StoreKit 2 processes payment
- RevenueCat validates purchase
- Premium features unlocked
- Purchase animation played (purchase.pag)

---

### 8. Data Sync & Persistence

**Local Storage:**
- Core Data database (SnapWords.momd)
- Words, stickers, progress stored locally
- UserDefaults for preferences
- Image cache via Kingfisher

**Backend Sync:**
- Progress synced to backend (app-api.zenshine.app)
- Sticker collection synced
- Learning data synced
- Subscription status synced

**Offline Mode:**
- Local dataset available offline
- Core Data accessible offline
- AI features require internet
- Sync when connection available

---

### 9. Gamification Flow

**Sticker Rewards:**
- Learn word → earn sticker
- Complete category → earn special sticker
- Daily streak → bonus sticker
- Monthly challenge → exclusive sticker

**Particle Effects:**
- Dust effects on sticker unlock
- Leaf effects on purchase
- Confetti on completion
- Logo animation on achievements

**Celebration Animations:**
- Lottie animations on milestones
- Congratulations.json on achievements
- What's new GIFs on feature unlock

---

### 10. Complete User Experience Summary

**New User Flow:**
1. App launch → Language selection
2. Onboarding video → Tutorial
3. Camera capture → Object recognition
4. Translation → Flashcard creation
5. TTS pronunciation → Learning
6. Sticker earned → Collection
7. Review → Practice
8. Progress → Unlock new categories

**Returning User Flow:**
1. App launch → Dashboard
2. Check daily missions → Complete tasks
3. Camera capture → Learn new words
4. Review flashcards → Practice
5. Check sticker collection → View progress
6. Voice practice → Pronunciation
7. Sync progress → Backup

**Learning Loop:**
- Capture object → Recognize → Translate → Learn → Practice → Earn sticker → Repeat

---

## What Cannot Be Verified

- Core Data model schema (binary .mom/.omo files not readable)
- Exact object recognition accuracy
- AI API response format (only endpoints known)
- Specific gamification rules (sticker earning criteria)
- Premium feature details
- Backend database structure
- Exact animation timing and playback logic
- User interaction handling details
- Dynamic asset loading logic
- Offline mode implementation details

**Reason:** Binary files (Core Data model, compiled assets) and server-side implementation require deeper reverse engineering beyond static analysis.
