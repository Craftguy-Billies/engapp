# WordBranch (English4Formosa) Android App - In-Depth Analysis

## App Identity

- **Package ID:** com.english4formosa.www
- **App Name:** WordBranch
- **Version:** Build 310 (from metadata)
- **Minimum Android SDK:** 16 (compileSdkVersion="36", platformBuildVersionName="16")
- **Category:** Education (English vocabulary learning for Taiwan)
- **Platform:** Android (Universal)
- **Framework:** Flutter (Flutter embedding v2)
- **Architecture:** Split APK (base + config APKs for different languages and architectures)

---

## Dataset Analysis (Detailed)

### Data Format and Structure

**Database Format:** SQLite 3.x
**File Size:** 14.5MB (14,581,760 bytes)
**SQLite Version:** 3040001
**Total Words:** 104,004
**Total Pronunciation Patterns:** 539

### Table Schemas (Exact Structure)

**1. word Table (Main Vocabulary)**
```sql
CREATE TABLE word (
    id INT PRIMARY KEY,
    word TEXT COLLATE NOCASE NOT NULL,
    base INTEGER NULL,
    definition TEXT NOT NULL,
    kk TEXT NOT NULL,
    FOREIGN KEY (base) REFERENCES word(id)
);
```

**Field Descriptions:**
- **id:** Unique integer identifier for each word
- **word:** The English word (case-insensitive collation)
- **base:** Reference to base word id (for word families, NULL if base word)
- **definition:** Word definition (appears to contain Chinese definitions)
- **kk:** Phonetic notation (KK phonetic system for English pronunciation)

**Sample Data Structure:**
```
id | word        | base  | definition                        | kk
---|-------------|-------|-----------------------------------|-----
1  | fawn        | NULL  | (n.)小鹿(vi.)奉承,鬧著玩,撒嬌      | fɔn
3  | localizes   | 8391  |                                   |
4  | fleeces     | 71402 |                                   |
```

**2. prs Table (Pronunciation Patterns)**
```sql
CREATE TABLE prs (
    id INT PRIMARY KEY,
    key TEXT COLLATE NOCASE NOT NULL,
    type TEXT NOT NULL,
    variations TEXT NOT NULL,
    meaning TEXT NOT NULL,
    meaning_en TEXT NOT NULL,
    matching_ch TEXT NOT NULL,
    categories TEXT NOT NULL,
    vid TEXT NULL,
    idx INTEGER NOT NULL
);
```

**Field Descriptions:**
- **id:** Unique pattern identifier
- **key:** Pattern key (e.g., "ad", "con", "re")
- **type:** Pattern type (e.g., "p" for prefix)
- **variations:** Comma-separated pattern variations (e.g., "a,ac,af,ag,al,an,ap,ar,as,at")
- **meaning:** Chinese meaning of the pattern
- **meaning_en:** English meaning of the pattern
- **matching_ch:** Chinese characters that match the pattern
- **categories:** Categories the pattern belongs to
- **vid:** Video ID (NULL for text-only patterns)
- **idx:** Index/position for ordering

**Sample Data Structure:**
```
id | key | type | variations                    | meaning     | meaning_en  | matching_ch        | categories | vid           | idx
---|-----|------|-------------------------------|-------------|-------------|---------------------|-------------|---------------|-----
2  | ad  | p    | a,ac,af,ag,al,an,ap,ar,as,at | 向前        | to, toward  | 前                  | 2           | 7R0sMsloPmw   | 0
13 | con | p    | co,col,cor,com               | 共同, 一起   | together    | 共, 同, 合, 集, 合   | 1           | HfqCsc8noEc   | 1
61 | re  | p    |                              | 向後, 再     | back, again | 再, 回, 重, 復, 反   | 1           | otHmAObxlks   | 2
```

**3. word_stat Table (Word Statistics)**
```sql
CREATE TABLE word_stat (
    word INTEGER NOT NULL,
    learn INTEGER NOT NULL,
    queue INTEGER NOT NULL,
    lookup INTEGER NOT NULL,
    hint INTEGER NOT NULL,
    FOREIGN KEY (word) REFERENCES word(id),
    UNIQUE(word)
);
```

**Field Descriptions:**
- **word:** Reference to word.id
- **learn:** Number of times word was learned
- **queue:** Queue position for learning
- **lookup:** Number of times word was looked up
- **hint:** Number of hints used for this word

**4. prs_word Table (Pattern-Word Relationships)**
```sql
CREATE TABLE prs_word (
    prs INTEGER NOT NULL,
    word INTEGER NOT NULL,
    FOREIGN KEY (prs) REFERENCES prs(id),
    FOREIGN KEY (word) REFERENCES word(id),
    UNIQUE(prs, word)
);
```

**Purpose:** Links pronunciation patterns to specific words

**5. substring Table (Substring Relationships)**
```sql
CREATE TABLE substring (
    word INTEGER NOT NULL,
    substring INTEGER NOT NULL,
    FOREIGN KEY (word) REFERENCES word(id),
    FOREIGN KEY (substring) REFERENCES word(id),
    UNIQUE(word, substring)
);
```

**Purpose:** Links words that contain other words as substrings (e.g., "localize" contains "local")

**6. antonym Table (Antonym Relationships)**
```sql
CREATE TABLE antonym (
    word INTEGER NOT NULL,
    antonym INTEGER NOT NULL,
    FOREIGN KEY (word) REFERENCES word(id),
    FOREIGN KEY (antonym) REFERENCES word(id),
    UNIQUE(word, antonym)
);
```

**Purpose:** Bidirectional antonym relationships between words

**7. synonym Table (Synonym Relationships)**
```sql
CREATE TABLE synonym (
    word INTEGER NOT NULL,
    synonym INTEGER NOT NULL,
    FOREIGN KEY (word) REFERENCES word(id),
    FOREIGN KEY (synonym) REFERENCES word(id),
    UNIQUE(word, synonym)
);
```

**Purpose:** Bidirectional synonym relationships between words

**8. static Table (Static Configuration)**
```sql
CREATE TABLE static (
    name TEXT COLLATE NOCASE NOT NULL,
    value TEXT NOT NULL,
    UNIQUE(name)
);
```

**Purpose:** Stores app configuration and vocabulary deck structures in JSON format

**Data Format:** JSON string containing nested deck structures with word IDs

**9. pair_word Table (Word Pairs)**
```sql
CREATE TABLE pair_word (
    type INTEGER NOT NULL,
    word INTEGER NOT NULL,
    paired_word INTEGER NOT NULL,
    FOREIGN KEY (word) REFERENCES word(id),
    FOREIGN KEY (paired_word) REFERENCES word(id),
    UNIQUE(type, word, paired_word)
);
```

**Purpose:** Type-specific word pairings (e.g., collocations, phrase pairs)

**10. vocabs Table (Vocabulary Decks)**
```sql
CREATE TABLE vocabs (
    id INTEGER NOT NULL PRIMARY KEY,
    title TEXT NOT NULL,
    vocabs TEXT NOT NULL
);
```

**Purpose:** Vocabulary deck definitions with word lists

**11. category Table (Categories)**
```sql
CREATE TABLE category (
    id INTEGER NOT NULL PRIMARY KEY,
    name TEXT NOT NULL,
    is_public BOOLEAN NOT NULL
);
```

**Purpose:** Category definitions (public vs private)

**12. category_word Table (Category-Word Relationships)**
```sql
CREATE TABLE category_word (
    category INTEGER NOT NULL,
    word INTEGER NOT NULL,
    FOREIGN KEY (category) REFERENCES category(id),
    FOREIGN KEY (word) REFERENCES word(id),
    UNIQUE(category, word)
);
```

**Purpose:** Links categories to words

**13. prs_ranking Table (Pattern Rankings)**
```sql
CREATE TABLE prs_ranking (
    prs INTEGER NOT NULL,
    stats TEXT NOT NULL,
    FOREIGN KEY (prs) REFERENCES prs(id),
    UNIQUE(prs)
);
```

**Purpose:** Stores ranking statistics for pronunciation patterns

### Data Size and Scale

**Database Size:** 14.5MB (14,581,760 bytes)
**Page Count:** 3,560 database pages
**Schema Version:** 4

**Record Counts:**
- **word:** 104,004 records
- **prs:** 539 records
- **prs_word:** Pattern-word relationships
- **substring:** Substring relationships
- **antonym:** Antonym relationships
- **synonym:** Synonym relationships
- **static:** Configuration records (JSON data)
- **pair_word:** Word pair relationships
- **vocabs:** Vocabulary deck records
- **category:** Category records
- **category_word:** Category-word relationships
- **prs_ranking:** Pattern ranking records

### Data Categorization

**1. By Word Type (from prs table):**
- **Prefixes (type='p'):** ad, con, re, etc.
- **Other pattern types:** (indicated by type field)

**2. By Exam Level (from static table JSON):**
- **B4L8梗單:** Grade 4, Lesson 8 mnemonic deck
- **B4L9梗單:** Grade 4, Lesson 9 mnemonic deck
- **B5L1梗單:** Grade 5, Lesson 1 mnemonic deck
- **B5L2梗單:** Grade 5, Lesson 2 mnemonic deck
- **B5L3梗單:** Grade 5, Lesson 3 mnemonic deck
- **B5L4梗單:** Grade 5, Lesson 4 mnemonic deck
- **B5L5梗單:** Grade 5, Lesson 5 mnemonic deck
- **B5L6梗單:** Grade 5, Lesson 6 mnemonic deck

**3. By Exam Year (學測字中字 - College Entrance Exam):**
- **114學測經典字中字:** 2024 exam
- **113學測經典字中字:** 2023 exam
- **112學測經典字中字:** 2022 exam
- **111學測經典字中字:** 2021 exam
- **110學測經典字中字:** 2020 exam
- **109學測經典字中字:** 2019 exam
- **108學測經典字中字:** 2018 exam

**4. By Word Relationships:**
- **Base words:** Words with base=NULL
- **Derived words:** Words with base=reference to base word
- **Substrings:** Words containing other words
- **Antonyms:** Opposite meaning words
- **Synonyms:** Similar meaning words
- **Pairs:** Collocation pairs

**5. By Learning Progress (word_stat table):**
- **learn count:** How many times word was learned
- **queue:** Learning queue position
- **lookup:** Lookup frequency
- **hint:** Hint usage frequency

### Data Organization Pattern

**Hierarchical Structure:**
1. **Root decks:** Main vocabulary categories (e.g., "[WordBranch師訓] 學測字中字")
2. **Sub-decks:** Year-specific exam decks (e.g., "114學測經典字中字")
3. **Word lists:** Arrays of word IDs within each deck

**JSON Structure (static table value field):**
```json
{
  "decks": [
    {
      "id": deck_id,
      "name": "deck_name",
      "sub_decks": [
        {
          "id": subdeck_id,
          "name": "subdeck_name",
          "sub_decks": [],
          "words": [word_id_1, word_id_2, ...]
        }
      ],
      "words": [word_id_1, word_id_2, ...]
    }
  ]
}
```

### Data Massiveness Assessment

**Scale:** Massive for a mobile app
- **104,004 words:** Comprehensive English vocabulary
- **539 pronunciation patterns:** Extensive pattern coverage
- **14.5MB database:** Substantial local data
- **Multiple relationship types:** Complex word network
- **Exam-specific organization:** Targeted for Taiwan education system

**Storage Strategy:**
- **Bundled in assets:** Pre-loaded with app
- **SQLite format:** Efficient querying and indexing
- **Foreign key relationships:** Normalized database structure
- **Case-insensitive collation:** For word lookups
- **Local-only:** No server sync for word data (static content)

---

## Dataset Analysis (Previous Summary)

### Local Database (word.db)

**File Location:** `assets/flutter_assets/assets/word.db`
**File Size:** 14.5MB
**Format:** SQLite 3.x database (version 3040001)

**Database Schema:**

**Tables:**
1. **word** - Main vocabulary table (104,004 words)
   - id (int, primary key)
   - word (text, collate nocase)
   - base (int, foreign key to word.id)
   - definition (text)
   - kk (text - phonetic notation)

2. **prs** - Pronunciation patterns (539 records)
   - id (int, primary key)
   - key (text, collate nocase)
   - type (text)
   - variations (text)
   - meaning (text)
   - meaning_en (text)
   - matching_ch (text)
   - categories (text)
   - vid (text)
   - idx (int)

3. **word_stat** - Word statistics
   - word (int, foreign key to word.id)
   - learn (int)
   - queue (int)
   - lookup (int)
   - hint (int)

4. **prs_word** - Pattern-word relationships
   - prs (int, foreign key to prs.id)
   - word (int, foreign key to word.id)

5. **substring** - Substring relationships
   - word (int, foreign key to word.id)
   - substring (int, foreign key to word.id)

6. **antonym** - Antonym relationships
   - word (int, foreign key to word.id)
   - antonym (int, foreign key to word.id)

7. **synonym** - Synonym relationships
   - word (int, foreign key to word.id)
   - synonym (int, foreign key to word.id)

8. **static** - Static configuration data (JSON format)
   - name (text, collate nocase)
   - value (text)

9. **pair_word** - Word pairs
   - type (int)
   - word (int, foreign key to word.id)
   - paired_word (int, foreign key to word.id)

10. **vocabs** - Vocabulary decks
    - id (int, primary key)
    - title (text)
    - vocabs (text - JSON)

11. **category** - Categories
    - id (int, primary key)
    - name (text)
    - is_public (boolean)

12. **category_word** - Category-word relationships
    - category (int, foreign key to category.id)
    - word (int, foreign key to word.id)

13. **prs_ranking** - Pattern rankings
    - prs (int, foreign key to prs.id)
    - stats (text)

**Dataset Characteristics:**
- **Word Count:** 104,004 English words
- **Pronunciation Patterns:** 539 patterns
- **Relationships:** Antonyms, synonyms, substrings, word pairs
- **Learning Statistics:** Track learn progress, queue, lookup, hint counts
- **Vocabulary Decks:** Organized by Taiwan education levels (B4L8梗單, B4L9梗單, B5L1梗單, etc.)
- **Exam Focus:** 學測字中字 (Taiwan college entrance exam words) with year-specific decks (108-114學測)

**Static Data Content:**
- Vocabulary deck structures with hierarchical organization
- Word lists referenced by IDs
- Sub-decks for different exam years
- Learning progress tracking data

---

## API Calls Analysis

### Backend Server

**Primary Domain:** `tw.wordbranch.com`
- **Deep Linking:** https://tw.wordbranch.com
- **Purpose:** Deep linking for app navigation
- **SSL:** HTTPS only (auto-verify enabled)

### Firebase Services

**Firebase Analytics:**
- **API:** https://app-measurement.com/a
- **API:** https://app-measurement.com/s/d (Google Signal)
- **Purpose:** User analytics, event tracking
- **Components:** Firebase Analytics, Firebase Core

**Firebase Messaging:**
- **Service:** FCM (Firebase Cloud Messaging)
- **Purpose:** Push notifications
- **Components:** Firebase Messaging, Firebase Core

**Firebase Installations:**
- **Purpose:** App installation tracking
- **Components:** Firebase Installations

### Google Services

**Google Play Billing:**
- **Service:** In-app purchases
- **Version:** 7.1.1
- **Purpose:** Subscription and one-time purchases

**Google Sign-In:**
- **Scope:** https://www.googleapis.com/auth/games
- **Scope:** https://www.googleapis.com/auth/games_lite
- **Purpose:** User authentication

**Google ML Kit:**
- **Service:** Barcode scanning
- **Purpose:** Barcode recognition for features

**Google Ad Services:**
- **Permissions:** ACCESS_ADSERVICES_ATTRIBUTION, ACCESS_ADSERVICES_AD_ID
- **Permissions:** ACCESS_ADSERVICES_CUSTOM_AUDIENCE, ACCESS_ADSERVICES_TOPICS
- **Purpose:** Ad attribution and targeting

### Facebook SDK

**Facebook Authentication:**
- **Purpose:** Social login
- **Components:** FacebookActivity, CustomTabActivity
- **Deep Link:** fbconnect://cct.com.english4formosa.www

**Facebook API:**
- **Device Auth:** https://facebook.com/device?user_code={code}&qr=1
- **Documentation:** https://developers.facebook.com/docs/android/getting-started

### Other APIs

**Google Plus (Deprecated):**
- **URL:** https://plus.google.com/circles/find
- **Status:** Legacy code (Google+ discontinued)

**Google Search:**
- **URL:** https://www.google.com
- **Purpose:** Web search integration

**Flutter Documentation:**
- **URL:** https://docs.flutter.dev/deployment/android
- **Purpose:** Architecture documentation reference

---

## Legal Issues Analysis

### Permissions

**Network & Connectivity:**
- INTERNET - Required for API calls
- ACCESS_NETWORK_STATE - Check network status

**Camera:**
- CAMERA - For barcode scanning features
- android.hardware.camera - Optional feature

**Notifications:**
- POST_NOTIFICATIONS - Push notifications (Android 13+)
- RECEIVE_BOOT_COMPLETED - Auto-start on boot
- WAKE_LOCK - Keep device awake for background tasks
- VIBRATE - Vibration feedback

**Advertising & Attribution:**
- com.google.android.gms.permission.AD_ID - Access Google Advertising ID
- ACCESS_ADSERVICES_ATTRIBUTION - Ad attribution tracking
- ACCESS_ADSERVICES_AD_ID - Ad ID access
- ACCESS_ADSERVICES_CUSTOM_AUDIENCE - Custom audience targeting
- ACCESS_ADSERVICES_TOPICS - Ad topics targeting

**Billing:**
- com.android.vending.BILLING - In-app purchases
- com.google.android.finsky.permission.BIND_GET_INSTALL_REFERRER_SERVICE - Install referrer tracking

**Firebase:**
- com.google.android.c2dm.permission.RECEIVE - FCM messages

**Badge Permissions (Multiple Launchers):**
- Samsung: READ/WRITE badge permissions
- HTC: READ/UPDATE shortcut permissions
- Sony: BROADCAST/PROVIDER badge permissions
- AndDoes: UPDATE_COUNT badge permission
- Huawei: CHANGE/READ/WRITE badge permissions
- Oppo: READ/WRITE badge permissions
- Every: BADGE_COUNT_READ/WRITE permissions

**System:**
- BROADCAST_CLOSE_SYSTEM_DIALOGS - Close system dialogs
- BIND_NOTIFICATION_LISTENER_SERVICE (maxSdkVersion=22) - Notification listener (legacy)

### Data Collection

**Firebase Analytics:**
- User behavior tracking
- Event logging
- Crash reporting (Firebase Crashlytics)
- Installation tracking

**Ad Attribution:**
- Google Advertising ID collection
- Install referrer tracking
- Ad services attribution data

**Learning Data:**
- Word lookup statistics
- Learning progress (word_stat table)
- User preferences
- Vocabulary deck progress

**Potential Concerns:**
- **Ad ID Collection:** Access to Google Advertising ID for ad targeting
- **Install Referrer:** Tracking app installation sources
- **Firebase Analytics:** Comprehensive user behavior tracking
- **Camera Access:** For barcode scanning (legitimate use case)

### Compliance Considerations

**GDPR/CCPA:**
- No explicit privacy policy found in APK
- Ad ID collection requires user consent in EU/California
- Firebase analytics may require consent management

**Taiwan PDPA:**
- App targets Taiwan users (Formosa in name)
- Learning data collection may be educational purpose
- No explicit consent mechanism found in manifest

**COPPA:**
- App appears to target students (exam preparation)
- No age verification mechanism evident
- May require parental consent for users under 13

---

## AI Models Analysis

### ML Kit Barcode Scanning

**Framework:** Google ML Kit
**Purpose:** Barcode recognition for app features

**TensorFlow Lite Models:**

1. **barcode_ssd_mobilenet_v1_dmp25_quant.tflite** (390KB)
   - **Model:** MobileNet V1 SSD (Single Shot Detector)
   - **Quantization:** Quantized (8-bit integers)
   - **Purpose:** Object detection for barcode localization
   - **Architecture:** MobileNet-based SSD

2. **oned_auto_regressor_mobile.tflite** (214KB)
   - **Model:** One-Dimensional Auto-Regressor
   - **Purpose:** Barcode value regression
   - **Architecture:** Mobile-based regression model

3. **oned_feature_extractor_mobile.tflite** (277KB)
   - **Model:** One-Dimensional Feature Extractor
   - **Purpose:** Feature extraction from barcode regions
   - **Architecture:** Mobile-based feature extractor

**AI Capabilities:**
- Barcode scanning and recognition
- Real-time object detection
- On-device inference (no server required)
- Optimized for mobile (quantized models)

**Use Cases:**
- Likely used for scanning vocabulary books
- QR code scanning for sharing decks
- Possibly scanning exam materials

---

## Backend Functionality Analysis

### Server Architecture

**Primary Backend:** tw.wordbranch.com
- **Type:** Deep linking server
- **Purpose:** App navigation and routing
- **Protocol:** HTTPS with auto-verification

**Firebase Backend:**
- **Analytics:** User behavior tracking
- **Messaging:** Push notification delivery
- **Crashlytics:** Crash reporting
- **Installations:** Installation tracking

### Local Backend (SQLite Database)

**Database Management:**
- **Format:** SQLite 3.x
- **Size:** 14.5MB
- **Location:** Assets folder (bundled with app)
- **Access:** Flutter sqflite plugin

**Data Persistence:**
- **Word Data:** Pre-loaded in assets (read-only)
- **User Progress:** Likely stored in separate local database (app-specific)
- **Configuration:** Static table for app configuration

### Backend Services

**Flutter Plugins:**
- **firebase_core:** Firebase initialization
- **firebase_analytics:** Analytics tracking
- **firebase_messaging:** Push notifications
- **google_sign_in:** Google authentication
- **flutter_inappwebview:** In-app browser
- **image_picker:** Image selection
- **url_launcher:** URL handling
- **share_plus:** Content sharing
- **awesome_notifications:** Notification management

**Third-Party Services:**
- **Facebook SDK:** Social authentication
- **Google Play Billing:** In-app purchases
- **ML Kit:** Barcode scanning
- **RevenueCat:** (Not found - may use direct billing)

### Data Flow

**Word Learning Flow:**
1. App launches → Load word.db from assets
2. User selects vocabulary deck
3. Words fetched from database by deck ID
4. User learns words → Update word_stat
5. Progress saved to local database
6. Analytics sent to Firebase

**Barcode Scanning Flow:**
1. Camera permission granted
2. ML Kit barcode models loaded
3. Camera frame captured
4. TensorFlow Lite inference on device
5. Barcode detected → Process result
6. Result used for feature (deck lookup, etc.)

**Authentication Flow:**
1. User selects sign-in method
2. Google Sign-In or Facebook SDK called
3. OAuth flow completed
4. User token stored locally
5. User data synced with backend (if applicable)

---

## Frontend UI Framework Analysis

### Flutter Framework

**Flutter Version:** Flutter embedding v2
**Dart:** Flutter Dart code
**Architecture:** Single-activity Flutter app

**Main Activity:**
- **Class:** com.english4formosa.www.MainActivity
- **Theme:** LaunchTheme, NormalTheme
- **Launch Mode:** singleTask
- **Config Changes:** locale, keyboard, orientation, screen size, etc.

### Flutter Plugins

**UI Plugins:**
- **flutter_inappwebview:** In-app browser for web content
- **image_picker:** Image selection from gallery/camera
- **url_launcher:** Open URLs in browser
- **share_plus:** Share content to other apps

**Notification Plugins:**
- **awesome_notifications:** Advanced notification management
- **firebase_messaging:** FCM push notifications

**Authentication Plugins:**
- **google_sign_in:** Google OAuth
- **sign_in_with_apple:** Apple Sign-In

**Utility Plugins:**
- **path_provider:** File system access
- **shared_preferences:** Key-value storage
- **camera:** Camera access
- **permission_handler:** Runtime permissions

### UI Components

**Views:**
- **MainActivity:** Main Flutter activity
- **WebViewActivity:** In-app browser
- **InAppBrowserActivity:** Browser with controls
- **ChromeCustomTabsActivity:** Chrome custom tabs

**Notification UI:**
- **DartNotificationActionReceiver:** Notification actions
- **DartDismissedNotificationReceiver:** Dismiss notifications
- **DartScheduledNotificationReceiver:** Scheduled notifications
- **StatusBarManager:** Notification listener service

### Assets

**Images:**
- **banner.jpg:** Banner image (940KB)
- **gamebanner.svg:** Game banner SVG (121KB)
- **rush_banner.svg:** Rush banner SVG (132KB)
- **celebration.png:** Celebration image (2.5KB)
- **brain.svg:** Brain icon (1.3KB)
- **logo3_light_pencil.svg:** Logo SVG (1.1KB)
- **referral_card.svg:** Referral card SVG (1.3KB)

**Icons:**
- **navbar/**: 23 navigation bar icons
- **icons/**: 39 app icons
- **background/**: 2 background images
- **search/**: 3 search icons
- **school/**: 1 school icon
- **game/**: 2 game icons

**Fonts:**
- **fonts/**: Custom fonts (3 files)
- **external/fonts/**: External fonts (8 files)

**Shaders:**
- **shaders/**: 2 shader files (likely for effects)

### Localization

**Supported Languages (from split APKs):**
- **config.en.apk:** English
- **config.es.apk:** Spanish
- **config.fr.apk:** French
- **config.de.apk:** German
- **config.it.apk:** Italian
- **config.ja.apk:** Japanese
- **config.ko.apk:** Korean
- **config.zh.apk:** Chinese (Simplified)
- **config.ar.apk:** Arabic
- **config.hi.apk:** Hindi
- **config.in.apk:** Indonesian
- **config.my.apk:** Malay
- **config.pt.apk:** Portuguese
- **config.ru.apk:** Russian
- **config.th.apk:** Thai
- **config.tr.apk:** Turkish
- **config.vi.apk:** Vietnamese

**Architecture:** Dynamic feature delivery for language resources

### Native Libraries

**config.armeabi_v7a.apk:** 23.2MB
- **Purpose:** Native libraries for ARMv7 architecture
- **Contents:** Flutter engine, ML Kit libraries, other native code

**config.mdpi.apk:** 59KB
- **Purpose:** Resources for medium DPI screens
- **Contents:** Screen density-specific resources

---

## App Features (Inferred)

### Vocabulary Learning

**Core Feature:**
- 104,004 English words database
- Pronunciation patterns (539 patterns)
- Word relationships (antonyms, synonyms, substrings)
- Learning statistics tracking
- Vocabulary deck organization

**Exam Preparation:**
- Taiwan college entrance exam (學測) focus
- Year-specific exam decks (108-114學測)
- B4-B5 level vocabulary decks
- 梗單 (mnemonic decks)

### Gamification

**Features:**
- Game banner assets
- Rush mode banner
- Celebration animations
- Badge system (multiple launcher integrations)

### Social Features

**Authentication:**
- Google Sign-In
- Facebook Login
- Apple Sign-In

**Sharing:**
- Share Plus plugin
- Share vocabulary decks
- Referral system

### Barcode Scanning

**Purpose:**
- Scan vocabulary books
- QR code sharing
- Deck lookup via barcode

### In-App Purchases

**Billing:**
- Google Play Billing v7.1.1
- Subscription support
- One-time purchases

---

## Security & Privacy

### Exposed Information

**No Hardcoded API Keys Found:**
- Firebase configuration likely in google-services.json (not exposed in manifest)
- Facebook app ID and client token in strings (not exposed in decompiled manifest)

**Potential Concerns:**
- Ad ID collection for ad targeting
- Firebase analytics tracking
- Install referrer tracking

### Encryption

**SSL/TLS:**
- HTTPS for all external API calls
- Deep linking with auto-verification
- No evidence of custom encryption

### Data Storage

**Local Database:**
- SQLite database in assets (read-only)
- User progress in app-specific storage
- No evidence of encryption for local data

---

## What Cannot Be Verified

- Server-side API implementation (tw.wordbranch.com backend)
- Firebase configuration (google-services.json)
- Facebook app credentials (app ID, client token)
- User authentication flow details
- Specific gamification logic
- Backend data synchronization
- Offline mode implementation
- Specific learning algorithms
- Revenue model details

**Reason:** Server-side code, configuration files, and runtime behavior require dynamic analysis or server access beyond static APK analysis.

---

## Conclusion

**App Summary:**
WordBranch is a comprehensive English vocabulary learning app for Taiwan students, featuring a 104,000-word database, exam-focused vocabulary decks, barcode scanning, social authentication, and gamification elements. Built with Flutter, it leverages Firebase for analytics and messaging, Google ML Kit for barcode recognition, and multiple third-party services for authentication and billing.

**Key Technologies:**
- Flutter (UI framework)
- Firebase (backend services)
- Google ML Kit (AI/ML)
- SQLite (local database)
- TensorFlow Lite (on-device ML)

**Data Strategy:**
- Pre-loaded database in assets (14.5MB)
- Local progress tracking
- Firebase analytics for user insights
- Ad attribution for monetization

**Legal Considerations:**
- Comprehensive ad tracking permissions
- Camera access for legitimate barcode scanning
- Firebase analytics for user behavior
- No explicit privacy policy found in APK
- May require consent management for GDPR/CCPA compliance
