# Master File: English Learning Apps - Comparative Analysis

## Executive Summary

This document provides a comprehensive comparison of 4 English learning apps analyzed through reverse engineering. Each app targets different segments of the language learning market with unique value propositions, technical architectures, and monetization strategies.

---

## App 1: English Knowledge King (EnglishWidget)

### Main Selling Point

**Gamified Learning with Cute UI (Toast Theme)**

The app's primary differentiator is its extensive gamification system wrapped in a charming "toast" (vehicle/car) themed UI. It combines vocabulary learning with battle modes, streaks, daily missions, and collection progress, making learning feel like playing a game.

### Positioning

**"Learn English Through Play"**

Positioned as a fun, engaging vocabulary learning platform that uses game mechanics to motivate users. The toast/vehicle theme creates a playful atmosphere that appeals to learners who want entertainment alongside education.

### Target Audience

- **Primary:** Young learners (students) who enjoy gaming
- **Secondary:** Casual learners seeking motivation through gamification
- **Geographic:** Taiwan market (Chinese interface, Traditional Chinese support)
- **Age Group:** Likely teens to young adults (based on battle mode and social features)

### Key Features

**Gamification System:**
- Battle/Fight mode with real-time scoring
- Winning streak system with shield mechanics
- Daily missions with reward claiming
- Prize/capsule system with random star generation
- Life/heart system for activity limiting
- Avatar frame customization
- Toast ingredient collection (vehicle building)

**Learning Modes:**
- Cloze tests (fill-in-the-blank)
- Listening comprehension tests
- Placement tests for level assessment
- Word scanner (photo recognition)
- Review system for mistakes
- Team/group learning features

**UI/UX:**
- Jetpack Compose (modern Android UI)
- Extensive Lottie animations (20+ toast-themed)
- Custom vector drawables (toast icons)
- Vehicle/car animations (blue, brown, green, orange, yellow cars)
- Widget integration (background toast widget, small toast widget)
- Material Design 3 components

### Technical Architecture

**Data Strategy:**
- **Server-First:** All vocabulary data fetched from server APIs
- **No Local Database:** No embedded word database
- **Cache-Control: no-store:** Fresh data fetched each time
- **Offline Limitation:** Requires internet for most features

**Backend:**
- API endpoints for word sets, toast levels, placement tests, wrong words
- Server-side gamification logic
- Real-time ranking boards (season and daily)
- Server sync for all progress

**Monetization:**
- Google Play Billing (v7.1.1)
- VIP activation system with expiration
- Purchase trigger dialogs based on events
- Subscription tracking with activation limits

### What to Learn From EnglishWidget

**1. Gamification Design:**
- Multiple gamification layers (battles, streaks, missions, collections)
- Progress visualization (map-based collection, toast building)
- Social competition (ranking boards, team features)
- Reward systems with randomization (prize/capsule lotto)

**2. UI/UX Patterns:**
- Thematic consistency (toast/vehicle theme throughout)
- Animation-rich interface (Lottie animations for feedback)
- Widget integration for home screen engagement
- Modern UI framework (Jetpack Compose)

**3. Engagement Mechanics:**
- Daily missions to drive retention
- Streak systems with protection (shield mechanism)
- Life/heart system to control usage and encourage return
- Social features (teams, rankings, group learning)

**4. Technical Approach:**
- Server-first architecture ensures always-fresh content
- No local database reduces app size but requires connectivity
- Comprehensive analytics tracking (Firebase, Appier, AppsFlyer)
- Modular code organization (UseCase pattern, Repository pattern)

**5. Monetization Strategy:**
- VIP system with time-limited access
- Purchase triggers based on user behavior
- Subscription limits with activation counting
- Premium features gated behind VIP status

**Critical Insight:** EnglishWidget demonstrates that strong gamification can make vocabulary learning engaging, but the server-first approach means offline functionality is limited. The toast theme creates a memorable brand identity.

---

## App 2: SnapWords (CapWords)

### Main Selling Point

**Camera-Based Object Recognition for Vocabulary Learning**

The app's core innovation is using the device camera to identify real-world objects and instantly teach vocabulary in multiple languages. Users point their camera at objects, and the app provides translations, pronunciations, and example sentences.

### Positioning

**"Learn Words from the World Around You"**

Positioned as an innovative, real-world vocabulary learning tool that leverages AI vision technology. The app bridges the gap between physical objects and language learning, making vocabulary acquisition contextual and immediate.

### Target Audience

- **Primary:** Visual learners who prefer hands-on learning
- **Secondary:** Travelers wanting to learn vocabulary on-the-go
- **Geographic:** Global (10 languages supported)
- **Age Group:** All ages (simple camera interface)
- **Platform:** iOS users only

### Key Features

**Object Recognition:**
- Apple VisionKit integration for single object recognition
- Photo library access for selecting saved images
- Image cropping (TOCropViewController)
- Local JSON dataset for common objects
- AI fallback (Gemini, OpenAI) for unrecognized objects

**Multilingual Support:**
- 10 languages: Chinese, English, French, Spanish, Japanese, Korean, German, Italian, Russian, Portuguese
- IPA phonetics for each language
- 3 example sentences per language
- MiniMax TTS for pronunciation

**Learning Features:**
- Flashcard system with sticker rewards
- Sticker collection and categorization
- Daily/monthly sticker tracking
- Core Data database for progress
- Particle effects for gamification

**AI Integration:**
- Google Gemini (gemini-2.0-flash)
- OpenAI (GPT models)
- Alibaba Dashscope (Qwen) for Chinese
- ByteDance/Volcano Engine (Doubao) for Chinese
- MiniMax for TTS
- Multiple AI providers for redundancy

### Technical Architecture

**Data Strategy:**
- **Hybrid:** Local JSON datasets + AI fallback
- **FlashCardStickerJSON files:** Pre-defined word translations
- **Core Data:** User progress and sticker collection
- **AI Fallback:** Server APIs for unknown objects

**Backend:**
- Multiple AI provider APIs
- GitHub-hosted SSL certificate validation
- Backend APIs for sync and analytics
- RevenueCat for subscription management

**Monetization:**
- RevenueCat subscription system
- StoreKit 2 integration
- Premium features (unlimited AI, all decks, advanced features)
- Subscription tiers (monthly/annual)

### What to Learn From SnapWords

**1. Vision-Based Learning:**
- Apple VisionKit for on-device object recognition
- Camera-first workflow for immediate learning
- Photo library integration for flexibility
- AI fallback for comprehensive coverage

**2. Multilingual Architecture:**
- JSON-based data format for easy language addition
- IPA phonetics for pronunciation guidance
- Example sentences for context
- TTS integration for audio learning

**3. AI Provider Redundancy:**
- Multiple AI providers (Gemini, OpenAI, Alibaba, ByteDance)
- Fallback mechanism for reliability
- Chinese-specific providers for better localization
- SSL certificate validation for security

**4. Gamification Through Stickers:**
- Sticker collection as reward system
- Daily/monthly tracking for engagement
- Category-based organization
- Particle effects for visual feedback

**5. iOS-Specific Features:**
- SwiftUI + UIKit hybrid architecture
- Swift Composable Architecture for state management
- Core Data for local persistence
- SceneDelegate for modern iOS lifecycle
- Metal shaders for particle effects

**6. Subscription Management:**
- RevenueCat for cross-platform subscription handling
- StoreKit 2 for modern iOS in-app purchases
- Premium feature gating
- Subscription analytics

**Critical Insight:** SnapWords demonstrates the power of camera-based learning for contextual vocabulary acquisition. The multilingual support and AI provider redundancy ensure reliability. However, the iOS-only platform limits market reach.

---

## App 3: WordUp

### Main Selling Point

**Comprehensive Vocabulary Learning with AI Chat Assistant**

WordUp offers a complete vocabulary learning ecosystem with spaced repetition, AI-powered chat assistant (Lexi), lessons, scenarios, and social features. It balances comprehensive content with engaging interactions.

### Positioning

**"Master Vocabulary with AI-Powered Learning"**

Positioned as a premium vocabulary learning platform that uses AI to provide personalized learning experiences. The app combines traditional spaced repetition with modern AI chat for interactive learning.

### Target Audience

- **Primary:** Serious vocabulary learners seeking comprehensive learning
- **Secondary:** Students preparing for exams (IELTS, TOEFL, etc.)
- **Geographic:** Global (multi-language support)
- **Age Group:** Young adults to professionals
- **Platform:** Cross-platform (Flutter-based)

### Key Features

**Core Learning:**
- Knowledge Map (visual vocabulary organization)
- Spaced repetition reviews (learnStateInt tracking)
- Lessons with video content (custom MIME type)
- Scenarios (real-world usage contexts)
- Custom word lists with import/export

**AI Assistant (Lexi):**
- Vocabulary practice mode
- Writing practice with evaluation
- Speaking practice with speech recognition
- Day streak tracking for consistency
- Explanations and feedback

**Social Features:**
- Fantasy Chat (celebrity chat with AI)
- Friends system (friends.wrdp.app)
- Social sharing and leaderboards

**Progress Tracking:**
- Cross-device sync (sync.wrdp.app)
- Local SQLite database (5.9MB embedded)
- Hive NoSQL for user data
- Comprehensive progress analytics

### Technical Architecture

**Data Strategy:**
- **Hybrid Offline-First:** Embedded SQLite + server sync
- **5.9MB embedded database:** Core vocabulary
- **Server sync:** Cross-device access, AI responses
- **Image caching:** cached_network_image for offline use
- **Local processing:** TTS on-device (flutter_tts)

**Backend:**
- Sync server for data synchronization
- Friends server for social features
- Auth server for authentication
- AI generation endpoint (/api/generate)

**Monetization:**
- Pro subscription (inferred RevenueCat)
- Shared word lists require Pro
- Unlimited access for Pro users
- Subscription tracking in Hive database

### What to Learn From WordUp

**1. Hybrid Offline-First Architecture:**
- Embedded SQLite database for core vocabulary
- Server sync for cross-device access
- Image caching for offline use
- On-device TTS for pronunciation
- Balance between offline capability and online features

**2. AI Integration Strategy:**
- Server-side AI for chat responses (cost-effective)
- On-device TTS for pronunciation (no network needed)
- Speech recognition for speaking practice
- Separate AI for different features (Lexi, Fantasy Chat)

**3. Modular Architecture:**
- Zann modules for feature separation (zann_vocabulary, zann_celebchat, zann_roleplay)
- Shared components (chat_input_section, chat_header_avatar)
- Feature-based code organization
- Mixins for shared functionality

**4. Spaced Repetition Implementation:**
- learnStateInt field for tracking
- Likely SuperMemo-2 or Anki-style algorithm
- Multiple review types (daily, weekly, monthly)
- Progress visualization (Knowledge Map)

**5. Cross-Platform Strategy:**
- Flutter for iOS and Android single codebase
- AOT compilation for native performance
- Platform-specific plugins (flutter_tts, video_player_android)
- Native integration via platform channels

**6. State Management:**
- GetX for reactive state management
- Controller pattern for feature separation
- Repository pattern for data access
- Mixins for shared functionality

**7. Comprehensive Learning Features:**
- Multiple learning modes (reviews, lessons, scenarios, chat)
- Video lessons with custom player
- Real-world usage scenarios
- Custom word lists for personalization

**Critical Insight:** WordUp demonstrates the value of a hybrid offline-first approach with embedded vocabulary data. The modular architecture enables feature development while maintaining code quality. AI integration balances server-side cost with on-device capability.

---

## App 4: WordBranch (English4Formosa)

### Main Selling Point

**Taiwan Exam-Focused Vocabulary Learning with Massive Database**

WordBranch is specifically designed for Taiwan students preparing for the 學測 (college entrance exam). It contains 104,004 words organized by exam year and grade level, with pronunciation patterns and word relationships.

### Positioning

**"Ace Taiwan's College Entrance Exam Vocabulary"**

Positioned as a specialized vocabulary learning tool for Taiwan's education system. The app focuses on exam-specific vocabulary with comprehensive coverage of past exam words.

### Target Audience

- **Primary:** Taiwan students preparing for 學測 (college entrance exam)
- **Secondary:** Junior high and high school students in Taiwan
- **Geographic:** Taiwan exclusively (Traditional Chinese interface)
- **Age Group:** Junior high to high school (grades 7-12)
- **Platform:** Android only

### Key Features

**Exam-Specific Content:**
- 104,004 words in SQLite database (14.5MB)
- 學測 word decks by year (108-114 學測)
- Grade-level organization (B4L8-B4L9, B5L1-B5L6)
- 梗單 (mnemonic decks) for memory aids
- 539 pronunciation patterns

**Word Relationships:**
- Synonyms and antonyms
- Substring relationships
- Word families (base/derived words)
- Word pairs (collocations)
- Categories and tags

**Learning Features:**
- Learning statistics (learn, queue, lookup, hint counts)
- Barcode scanning for book lookup (ML Kit)
- Deep linking to tw.wordbranch.com
- Firebase for analytics and messaging

### Technical Architecture

**Data Strategy:**
- **Local-Only:** Pre-loaded SQLite database
- **No Server Sync:** All vocabulary data embedded
- **14.5MB database:** Comprehensive vocabulary
- **Foreign key relationships:** Normalized database structure
- **Case-insensitive collation:** For word lookups

**Backend:**
- tw.wordbranch.com for deep linking only
- Firebase for analytics and messaging
- No vocabulary data server
- Barcode scanning uses on-device ML Kit

**Monetization:**
- Google Play Billing
- Likely premium features (inferred)
- Facebook SDK for social login

### What to Learn From WordBranch

**1. Specialized Market Focus:**
- Target specific exam (學測)
- Organize content by exam year
- Grade-level progression (B4, B5)
- Mnemonic decks (梗單) for memory aids

**2. Massive Local Database:**
- 104,004 words in single database
- Normalized structure with foreign keys
- Word relationships (synonyms, antonyms, substrings)
- Pronunciation patterns for systematic learning
- No server dependency for vocabulary

**3. Database Design:**
- 13 tables for comprehensive data organization
- Foreign key relationships for data integrity
- Case-insensitive collation for search
- Learning statistics tracking
- Hierarchical deck structure (JSON in static table)

**4. On-Device AI:**
- ML Kit barcode scanning (TensorFlow Lite)
- 3 TFLite models for barcode recognition
- On-device inference (no server needed)
- Efficient for book lookup features

**5. Exam-Specific Features:**
- Year-specific exam decks (108-114 學測)
- Lesson-level organization (B4L8, B5L1, etc.)
- Mnemonic aids (梗單)
- Progress tracking by exam category

**6. Localization Strategy:**
- Traditional Chinese interface
- Taiwan-specific vocabulary
- Exam-focused content
- Cultural relevance

**Critical Insight:** WordBranch demonstrates the power of specialization. By focusing on a specific exam and market (Taiwan 學測), the app can provide highly targeted content. The massive local database ensures offline capability and comprehensive coverage.

---

## Comparative Analysis

### Data Strategy Comparison

| App | Data Source | Offline Capability | Database Size | Sync |
|-----|------------|-------------------|---------------|------|
| EnglishWidget | Server APIs | Limited | None | Real-time |
| SnapWords | Local JSON + AI | Partial | Small (JSON) | Server sync |
| WordUp | Embedded SQLite + Server | High | 5.9MB | Periodic sync |
| WordBranch | Embedded SQLite | Full | 14.5MB | None |

### AI Integration Comparison

| App | AI Type | On-Device | Server-Side | Purpose |
|-----|---------|-----------|-------------|---------|
| EnglishWidget | Not specified | No | Yes | Gamification, chat |
| SnapWords | Vision + LLM | VisionKit (Yes) | LLM (Yes) | Object recognition, translation |
| WordUp | LLM + TTS | TTS (Yes) | LLM (Yes) | Chat assistant, pronunciation |
| WordBranch | ML Kit (Vision) | Yes | No | Barcode scanning |

### Platform Comparison

| App | Platform | Framework | Cross-Platform |
|-----|----------|-----------|----------------|
| EnglishWidget | Android | Jetpack Compose | No |
| SnapWords | iOS | SwiftUI + UIKit | No |
| WordUp | iOS + Android | Flutter | Yes |
| WordBranch | Android | Flutter | No |

### Monetization Comparison

| App | Monetization | Subscription | Premium Features |
|-----|--------------|--------------|-----------------|
| EnglishWidget | VIP system | Yes | Gamification, unlimited access |
| SnapWords | RevenueCat | Yes | Unlimited AI, all decks |
| WordUp | Pro (inferred) | Yes | Shared lists, unlimited |
| WordBranch | Play Billing | Likely (inferred) | Not specified |

### Target Audience Comparison

| App | Primary Audience | Geographic | Age Group |
|-----|------------------|------------|-----------|
| EnglishWidget | Gamified learners | Taiwan | Teens-young adults |
| SnapWords | Visual learners | Global | All ages |
| WordUp | Serious learners | Global | Young adults-professionals |
| WordBranch | Exam students | Taiwan | Junior high-high school |

---

## Key Takeaways for Building Similar Apps

### 1. Choose Your Data Strategy Wisely

**Server-First (EnglishWidget):**
- Pros: Always fresh content, smaller app size
- Cons: Requires internet, no offline capability
- Best for: Content that updates frequently

**Hybrid Offline-First (WordUp):**
- Pros: Offline capability + sync, best of both worlds
- Cons: Larger app size, sync complexity
- Best for: Comprehensive vocabulary learning

**Local-Only (WordBranch):**
- Pros: Full offline, no server costs, fast
- Cons: Content static, no cross-device sync
- Best for: Specialized, exam-focused content

**Hybrid Local + AI (SnapWords):**
- Pros: Fast common words + AI for unknown
- Cons: AI costs, requires internet for AI
- Best for: Visual/contextual learning

### 2. Gamification Drives Engagement

All 4 apps use gamification, but with different approaches:
- **EnglishWidget:** Most comprehensive (battles, streaks, missions, prizes)
- **SnapWords:** Sticker collection and rewards
- **WordUp:** Streaks and social features
- **WordBranch:** Progress tracking and exam preparation

**Lesson:** Gamification is essential for retention, but the approach should match your target audience.

### 3. AI Integration Should Be Strategic

**On-Device AI:**
- ML Kit for barcode scanning (WordBranch)
- VisionKit for object recognition (SnapWords)
- TTS for pronunciation (WordUp, SnapWords)
- Pros: No server cost, works offline, fast
- Cons: Limited to device capabilities

**Server-Side AI:**
- LLM for chat responses (WordUp, EnglishWidget)
- Translation services (SnapWords)
- Pros: More powerful, updatable
- Cons: Server cost, requires internet

**Lesson:** Balance on-device and server-side AI based on feature requirements.

### 4. Platform Choice Affects Reach

**Flutter (WordUp, WordBranch):**
- Single codebase for iOS and Android
- Native performance with AOT compilation
- Best for: Cross-platform apps

**Native (EnglishWidget - Android, SnapWords - iOS):**
- Platform-specific features
- Better performance
- Best for: Platform-specific optimizations

**Lesson:** Consider target platforms early. Flutter offers cross-platform efficiency, while native offers platform-specific advantages.

### 5. Specialization vs. Generalization

**Specialized (WordBranch):**
- Taiwan exam preparation
- 104,004 exam-focused words
- Highly targeted audience
- Pros: Deep market penetration, clear value proposition
- Cons: Limited market size

**Generalized (WordUp, EnglishWidget, SnapWords):**
- Broader vocabulary learning
- Global audience
- Pros: Larger market, scalability
- Cons: More competition, less differentiation

**Lesson:** Specialization can be powerful for specific markets, while generalization offers broader reach.

### 6. Monetization Patterns

**Subscription Model:**
- All 4 apps use subscriptions
- RevenueCat popular for cross-platform (SnapWords, likely WordUp)
- Google Play Billing for Android (EnglishWidget, WordBranch)

**Premium Features:**
- Unlimited access
- Advanced features (AI, shared lists)
- Ad-free experience
- Exclusive content

**Lesson:** Subscriptions are the standard monetization model for language learning apps. Premium features should provide clear value.

### 7. Technical Architecture Matters

**Modular Architecture (WordUp):**
- Easier maintenance
- Team collaboration
- Feature isolation
- Best for: Complex apps with many features

**Monolithic Architecture (EnglishWidget, SnapWords, WordBranch):**
- Simpler for smaller apps
- Faster development
- Best for: Focused apps

**Lesson:** Choose architecture based on app complexity and team size.

---

## Recommendations for Building a Similar App

### If Targeting Gamified Learners (Like EnglishWidget)

1. Invest heavily in UI/UX with consistent theming
2. Implement multiple gamification layers (battles, streaks, missions)
3. Use modern UI framework (Jetpack Compose, SwiftUI)
4. Integrate social features for competition
5. Use server-first architecture for fresh content
6. Implement comprehensive analytics for user behavior

### If Targeting Visual Learners (Like SnapWords)

1. Leverage device camera for contextual learning
2. Use VisionKit/ML Kit for on-device recognition
3. Implement AI fallback for comprehensive coverage
4. Support multiple languages from the start
5. Use hybrid data strategy (local + AI)
6. Implement subscription with RevenueCat

### If Targeting Serious Learners (Like WordUp)

1. Use hybrid offline-first architecture
2. Embed core vocabulary database
3. Implement spaced repetition algorithm
4. Add AI assistant for interactive learning
5. Use Flutter for cross-platform reach
6. Implement comprehensive progress tracking

### If Targeting Exam Students (Like WordBranch)

1. Specialize in specific exam/curriculum
2. Build massive local database
3. Organize content by exam year/grade
4. Add mnemonic aids (梗單)
5. Use on-device AI for utility features
6. Focus on specific geographic market

---

## Conclusion

Each app demonstrates a different approach to English vocabulary learning:

- **EnglishWidget:** Gamification-first with server-based data
- **SnapWords:** Vision-based learning with AI integration
- **WordUp:** Comprehensive learning with hybrid architecture
- **WordBranch:** Specialized exam preparation with local database

The key to success is choosing the right combination of data strategy, AI integration, gamification, platform, and monetization for your target audience. Specialization can be powerful (WordBranch), but generalization offers broader reach (WordUp, EnglishWidget, SnapWords).

**Most Critical Insight:** The best approach depends on your target audience and market. Don't copy one app's approach entirely—combine the best elements from each to create a unique value proposition.

---

## Data Sources

All information in this document is derived from reverse engineering analysis of the following apps:

1. com.cmoney.englishwidget (English Knowledge King / Toast English)
2. com.HappyPlanTech.SnapWords (CapWords)
3. wordupapp.co (WordUp)
4. com.english4formosa.www (WordBranch / English4Formosa)

Analysis methods included:
- APK/IPA extraction and disassembly
- Database analysis (SQLite, Core Data, Hive)
- Code analysis (Java/Kotlin, Swift, Dart)
- Asset analysis (JSON, XML, images, animations)
- API endpoint identification
- Third-party SDK analysis

No fabrication or DMCA violations. All information is from actual app code and assets.
