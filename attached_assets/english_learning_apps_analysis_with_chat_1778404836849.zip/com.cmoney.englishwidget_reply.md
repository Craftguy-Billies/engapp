# English Knowledge King (英文知識王) - Comprehensive Analysis

## App Identity

**App Name:** 英文知識王 (English Knowledge King)
**Package Name:** com.cmoney.englishwidget
**File:** com.cmoney.englishwidget.xapk
**Store Name:** English Knowledge King / Toast English

---

## Subscription System

### VIP Activation
- `VipActivationUseCase` handles VIP activation with `activationLimitVipRight()` method
- Takes parameters: `isAccepted` (boolean) and `expirationAt` (long timestamp)
- Returns `RequestVipRights` object
- Uses backend API endpoint: `activateLimitVipAuthority`

### Purchase Triggers
- `PurchaseTriggerUseCase` manages purchase trigger events
- Fetches `PurchaseTriggerRule` from `RemoteConfigRepository`
- Rule includes: `name`, `text`, `dialogImageUrl`, and list of `events`
- `triggerEvent()` method triggers purchase dialogs based on configured events
- Purchase dialog binding: `DialogPurchaseBinding`

### Purchase Logging
- `AppUserLogger.logAndTriggerPurchaseEvent()` used throughout app
- Tracks widget clicks, social shares (FB, Line, Instagram)
- Events tracked: `WidgetEvent.WidgetClick`, `ShareEvent.ShareFB`, `ShareEvent.ShareLine`, `ShareEvent.ShareIG`

### Limit VIP Dialog
- `UserUseCase` manages limit VIP dialog display
- `addLimitVipDialogDisplayCount()` - increments counter (max 3)
- `isNeedShowLimitVipDialogAtHome()` - checks if should show at home (after 3 displays)
- `isAlreadyShowLimitVipActivation()` - checks if already shown
- `resetLimitVipActivation()` - resets all VIP activation flags

### Billing Integration
- Uses Google Play Billing Library (version 7.1.1)
- `UserChoiceBillingListener` interface for alternative billing
- `BillingClient` with purchases listener
- Permission: `com.android.vending.BILLING`

---

## Dataset Storage and Separation

### Dataset Storage Method

**Conclusion: Datasets are NOT downloaded locally. They are fetched from server APIs.**

### Evidence

**1. No Local Database Files**
- No `.db` or `.sqlite` files found in app assets
- No embedded vocabulary database
- No local word data storage files

**2. Server-Based Data Fetching**

The app uses API endpoints to fetch word data:

**EnglishService.java API Endpoints:**
```java
@GET("api/UserWord/GetLatestWordSet")
Object getAllEnglishWords()

@GET("api/v3/ToastCollect/WordContent")
Object getMapCollectionWord(@Query("level") int level)

@GET("api/v3/ToastCollect/WordContent/MultiTest")
Object getMapCollectionMultiTestWord(@Query("level") int level)

@GET("api/v1/PlacementTest/{level}/word")
Object getPlacementWords(@Path("level") int level)

@GET("api/v3/UserWord/WordSets")
Object getWordSets(@Query("page") int page, @Query("pageSize") int pageSize)

@GET("api/v3/UserWord/WordSets/{wordSetId}/LocalizedDetails")
Object getWordSetDetail(@Path("wordSetId") String wordSetId)

@POST("api/v3/UserWord/WordSets/Default/Import")
Object importDefaultWordSets()
```

**3. Network Implementation**
- `NetworkImpl.java` handles API calls
- `EnglishService.java` defines API interface
- Response models: `ResponseWords.java`, `ResponseCollectionWord.java`, `NetworkWord.java`
- No local database queries found in code

---

## Dataset Separation

### Data Organization Structure

**1. Word Sets (Word Sets)**
- **API:** `api/v3/UserWord/WordSets`
- **Purpose:** Organized collections of words
- **Separation:** By word set ID
- **Operations:** Create, delete, clone, import default word sets
- **Status tracking:** `api/v3/UserWord/WordSets/Status`

**2. Toast Levels (Levels)**
- **API:** `api/v3/ToastCollect/WordContent` with `level` parameter
- **Purpose:** Progression-based word organization
- **Separation:** By level number (toast levels)
- **Related:** `api/v3/ToastCollect/ToastContent` for level list

**3. Stages within Levels**
- **API:** `api/v3/ToastCollect/Cloze/Level/{level}/Stage/{stage}`
- **Purpose:** Sub-level organization within each level
- **Separation:** By stage number within a level

**4. Placement Test Words**
- **API:** `api/v1/PlacementTest/{level}/word`
- **Purpose:** Assessment words for level placement
- **Separation:** By level and question count

**5. Wrong Words (Mistake Tracking)**
- **API:** `api/v2/UserWord/WrongWords`
- **Purpose:** User's incorrect words
- **Separation:** By user, time range (filterByAfterUpdateAt, filterByBeforeUpdateAt)
- **Operations:** Record, delete, update wrong words

**6. Multi-Test Collection Words**
- **API:** `api/v3/ToastCollect/WordContent/MultiTest`
- **Purpose:** Words for multiple-choice tests
- **Separation:** By level

**7. Grade-Based Organization**
- **API:** `api/v3/Grade`
- **Purpose:** Grade/level classification
- **Separation:** By grade system

**8. Listening Test Papers**
- **API:** `api/v3/ListeningTest/TestPapers`
- **Purpose:** Listening comprehension materials
- **Separation:** By difficulty and paper number

---

## Data Flow Architecture

```
User Action (Open Level/Word Set)
    ↓
API Call to Server (EnglishService)
    ↓
Fetch Word Data (ResponseWords, ResponseCollectionWord)
    ↓
Display in UI
    ↓
User Progress (Save to server via API)
    ↓
No Local Storage
```

---

## Cache Strategy

**Cache-Control Headers Found:**
```java
@Headers({"Cache-Control: no-store"})
@GET("api/UserWord/GetLatestWordSet")
Object getAllEnglishWords()

@Headers({"Cache-Control: no-store"})
@GET("api/v3/Grade")
Object getGradeList()

@Headers({"Cache-Control: no-store"})
@GET("api/v3/User/Grade")
Object getUserGrade()

@Headers({"Cache-Control: no-store"})
@GET("api/v3/User/PreviousGrade")
Object getUserPreviousGrade()
```

**Conclusion:** App uses `Cache-Control: no-store` for critical data, meaning no local caching. Data is fetched fresh from server each time.

---

## User Data Storage

**What is Stored Locally:**
- Login cache (LoginCacheDatabase)
- User settings (SettingsDataStore)
- User progress (sent to server via API)
- Wrong words (sent to server via API)

**What is NOT Stored Locally:**
- Vocabulary word data
- Word definitions
- Word pronunciations
- Word examples
- Word sets content

---

## Data Separation Summary

| Data Type | Separation Method | API Endpoint |
|-----------|------------------|--------------|
| Word Sets | By wordSetId | api/v3/UserWord/WordSets |
| Toast Words | By level | api/v3/ToastCollect/WordContent |
| Placement Words | By level, questionCount | api/v1/PlacementTest/{level}/word |
| Wrong Words | By user, time range | api/v2/UserWord/WrongWords |
| Cloze Quiz | By level, stage | api/v3/ToastCollect/Cloze/Level/{level}/Stage/{stage} |
| Grade Data | By grade | api/v3/Grade |
| Listening Test | By difficulty, paper | api/v3/ListeningTest/TestPapers |

---

## Local Word Storage

### Word Storage (Local Notes)
- Words stored in local database via `NoteRepository`
- `NoteOverview` contains `CategoryWords` by category
- `NoteRepository.getNoteOverviewFlow()` provides Flow of note data
- Words can be filtered by category and noted status

### Widget Notes
- `WidgetUseCase` manages widget word display
- `setWidgetNotes(List<Word>)` - saves words to SharedPreferences as JSON
- `getWidgetNotes()` - retrieves words from SharedPreferences
- `setWidgetNotePosition(int)` - saves current display position
- `getWidgetNotePosition()` - retrieves current position
- Words cycle through widget notes list

### TOEIC Word Bank
- `ToeicWordBankLocalDataSource` for TOEIC vocabulary
- `EnglishUseCase.getToeicWordBank()` retrieves TOEIC words
- `EnglishUseCase.getAllWords()` gets all words with favorite filtering

### Collection System
- `CollectionUseCase` manages word collections by level
- `getCollectionStageWords(levelId, isCheckService)` - gets words for specific stage
- `getCollectionStageMultiTestWords(levelId, isCheckService)` - gets words for multi-test
- `getUserMapCollectionTotalWords()` - returns total words in user's collection
- Collections include cloze stages with `clozeStages` and `clozeStageUnlockedAt`

---

## Test Types

### Cloze Test
- `ClozeUseCase` handles cloze (fill-in-the-blank) tests
- `getClozeQuizPapers(level, stage, onSuccess, onFailure)` - fetches quiz papers
- `uploadClozeTestResult(level, stage, onFailure)` - uploads test results
- `ClozeTestQuizModel` contains quiz data with text and translation
- `ClozeQuestionModel.ClozeQuizAnswer` stores answer information
- Activities: `ClozeTestActivity`, `ClozeResultActivity`

### Listening Test
- `ListeningUseCase` handles listening comprehension tests
- `getListeningTestPapers(difficulty, stage, onSuccess, onFailure)` - fetches listening papers
- `getListeningTestTodayStatistics()` - gets today's test statistics
- Activities: `ListeningTestActivity`, `ListeningResultActivity`
- Tutorial: `ShowListeningTutorialScreen` in MainActivity

### Battle Mode
- `FightUseCase` manages battle/competition mode
- `getBattleSeasonDailyRankingBoard()` - gets daily ranking board
- Activity: `BattleActivity`

---

## Word Scanner (Photo Recognition)

### WordScanner Feature
- `WordScannerViewModel` manages word scanning UI state
- `WordScannerUiState` contains:
  - `photos: List<Uri>` - list of captured photo URIs
  - `maxCount: int` - maximum photo count (default: 3)
  - `sendSuccess: boolean` - upload success status
  - `remainingUploadTimes: int` - remaining upload attempts (default: 10)
  - `isVip: boolean` - VIP status affects upload limits
- `removePhoto(index)` - removes photo at specific index
- `dismissToastMessage()` - dismisses toast notifications
- Activity: `WordScannerActivity`

### Image Upload
- `ImageUploadUseCase` handles photo uploads
- `ImageUploadUseCaseImpl.upload(context, cacheDir, uploadImageMainAndSubDirectory, photoUri)`
- Parameters include photo URI and upload directory configuration
- Upload dialog state: `UploadingDialogState`
- Toast messages: `WordScannerUiText` (including `UploadFailed`)

### Camera Integration
- Permission: `android.permission.CAMERA`
- Feature: `android.hardware.camera` (not required)
- Camera access likely through standard Android Camera API or third-party library

---

## Widget System

### Background Toast Widget
- `EnglishBgToastAppWidget` - main background widget
- Updates via `updateAppWidget(context, appWidgetManager, widgetId, layout, word)`
- Displays current word from widget notes
- `getCurrentDisplayWord()` - gets word at current position
- `shiftNoteDisplayPosition()` - cycles to next word
- Work manager: `BgToastWidgetUpdateWorker` with unique work name
- Logs widget click events: `WidgetEvent.WidgetClick("middle", "word")`

### Small Toast Widget
- `EnglishSmallToastAppWidget` - smaller widget variant
- Similar functionality to background widget
- Logs: `WidgetEvent.WidgetClick("piece", "word")`

### Widget Update Trigger
- `WORK_UPDATE_ACTION` intent triggers widget updates
- Uses WorkManager for periodic updates

---

## Word Markup/Notes

### Note System
- `WordMarkupActivity` - activity for marking up words
- Notes stored via `NoteRepository`
- `getNotedWordTexts()` - returns Set of noted word texts
- `getSaveNotes(dispatcher, currentLocale, notedWords)` - saves notes
- Notes can be filtered by category and locale

### Word Data Model
- `Word` class contains word information
- Words can be marked as favorites/noted
- Words include text and translation fields
- Words can be searched by keyword: `searchWordsByKeyword(keyword, favoriteList, currentLocale)`

---

## Learning Features

### Daily Learning
- `LearningDailyActivity` - daily learning activity
- Uses `LearningPlanActivity` for planning
- `LearningReviewActivity` - review learned content

### Personal Plan
- `PersonalPlanActivity` - personalized learning plan
- `ToeicPlanActivity` - TOEIC-specific planning

### User Level Testing
- `UserLevelTestActivity` - level assessment test
- `UserLevelResultActivity` - test results
- `JumpLevelTestActivity` - jump to specific level test
- `JumpLevelResultActivity` - jump test results

### Mistake Tracking
- `MistakeCategoryActivity` - review mistakes by category

---

## Team Features

### Group System
- `GroupUseCase` manages study groups
- `createGroup(teamName, teamDesc, password, imageId)` - creates new group
- `searchGroupByKeyword(regexName, pageIndex, pageCount)` - searches groups
- `getMyGroupQuiz()` - gets group quiz data
- `SearchActivity` - search for groups

---

## UI Framework

### Primary UI Framework: Jetpack Compose
- Evidence: File names like `ComposableSingletons$ToastCheerDialogKt.java`
- Evidence: `initComposeView` methods in multiple activities
- Evidence: Compose extension files (`ComposeExtKt.java`)

### Animation Framework: Lottie
- Evidence: Multiple .json animation files in assets and res/raw
- Evidence: Lottie animation zip files in assets

### Icon Format: Vector Drawables (XML) + WebP Images
- Evidence: Extensive drawable XML files
- Evidence: WebP image files for static assets

---

## Toast UI Components

### Toast Icons (Drawable XML)

**Toast-related Drawables:**
- `ic_toast.xml` - Main toast icon
- `ic_white_toast.xml` - White toast icon
- `ic_toast_has_win.xml` - Toast with win indicator
- `ic_toast_no_win.xml` - Toast without win indicator
- `ic_empty_toast.xml` - Empty toast icon
- `ic_normal_toast.xml` - Normal toast icon
- `ic_rank_toast.xml` - Rank toast icon
- `ic_tab_toast.xml` - Tab toast icon
- `ic_nav_toast.xml` - Navigation toast icon
- `ic_nav_toast_selected.xml` - Selected navigation toast icon
- `ic_horizontal_toast_bg.xml` - Horizontal toast background
- `ic_calendar_day_toast_start.xml` - Calendar toast start
- `ic_calendar_day_toast_middle.xml` - Calendar toast middle
- `ic_calendar_day_toast_end.xml` - Calendar toast end
- `ic_calendar_day_toast_single.xml` - Calendar toast single
- `achieved_toast.xml` - Achieved toast
- `un_achieved_toast.xml` - Unachieved toast
- `warning_toast.xml` - Warning toast
- `toast_hi.xml` - Toast greeting
- `toastman_ask_to_finish.xml` - Toast man asking to finish

### Toast Layouts

**Widget Layouts:**
- `english_small_toast_app_widget.xml` - Small toast app widget
- `item_event_notification_toast.xml` - Event notification toast item

**Widget Configuration:**
- `english_small_toast_app_widget_info.xml` - Widget info configuration

### Toast Animations (Lottie JSON)

**Asset Animations:**
- `assets/horse_toast.json` (2.5MB) - Horse toast animation
- `assets/toast_button.json` - Toast button animation
- `assets/toast_button_large.json` - Large toast button animation
- `assets/toast_stack.json` - Toast stack animation

**Res/raw Animations:**
- `anim_spinning_toast.json` - Spinning toast animation
- `ani_toastman_boxing.json` - Toast man boxing animation
- `shieldtoast.json` - Shield toast animation
- `celebrate_toast.json` - Celebrate toast animation
- `onedaywin.json` - One day win animation
- `sevendaywin.json` - Seven day win animation
- `onedaywin_jp.json` - One day win (Japanese)
- `sevendaywin_jp.json` - Seven day win (Japanese)

### Toast UI Components (Java/Kotlin)

**Toast Dialog:**
- `ToastCheerDialogKt.java` - Toast cheer dialog component
- `ComposableSingletons$ToastCheerDialogKt.java` - Compose singleton for toast dialog

**Toast Items:**
- `ToastCheckItem.java` - Toast check item component
- `ToastPosition.java` - Toast position model
- `ResponseToastItem.java` - Toast item response model

**Toast Progress:**
- `RequestToastProgressV2.java` - Toast progress request
- `RequestToastProgressSkipLevel.java` - Skip level request
- `uploadToastProgression` - Upload toast progression
- `convertToastProgression` - Convert toast progression

---

## Vehicle/Cars UI Components

**Note:** No fish icons found. The app uses car-related assets instead.

### Car Animation Assets (ZIP Files)

**Car Animations in assets/ directory:**
- `blue_car.zip` (60,715 bytes) - Blue car animation
- `brown_car.zip` (117,487 bytes) - Brown car animation
- `green_car.zip` (68,346 bytes) - Green car animation
- `orange_car.zip` (122,990 bytes) - Orange car animation
- `yellow_car.zip` (81,616 bytes) - Yellow car animation

**Purpose:** These appear to be Lottie animation files for vehicle-themed UI elements.

---

## Other Animation Assets

### Character Animations

**Toast Man:**
- `toast_hi.xml` - Toast man greeting (drawable)
- `toastman_ask_to_finish.xml` - Toast man asking to finish (drawable)
- `tutorial_earphone_toast_man.xml` - Tutorial toast man with earphone
- `tutorial_profile_toast_man.xml` - Tutorial toast man profile

**Other Characters:**
- `tutorial1.zip` (91,384 bytes) - Tutorial animation 1
- `tutorial2.zip` (444,219 bytes) - Tutorial animation 2
- `tutorial3.zip` (55,930 bytes) - Tutorial animation 3

### Fight/Battle Animations

**Fight Assets:**
- `fight_anim.zip` (885,899 bytes) - Fight animation
- `fight_enter.webp` (3,458 bytes) - Fight enter image
- `ani_toastman_boxing.json` - Toast man boxing animation

### Other Animations

**General Animations:**
- `lottie.zip` (561,848 bytes) - Lottie animation bundle
- `avatar_lottery.zip` (230,586 bytes) - Avatar lottery animation
- `win.zip` (254,160 bytes) - Win animation
- `laughing.zip` (3,555 bytes) - Laughing animation
- `sad.zip` (3,367 bytes) - Sad animation

**Effect Animations:**
- `bling.json` - Bling effect
- `shine.json` - Shine effect
- `shine_light.json` - Light shine effect
- `snow.json` - Snow effect
- `fly.json` - Fly effect
- `getshield.json` - Get shield effect
- `noshieldnowin.json` - No shield no win effect

---

## Icon System

### Navigation Icons

**Navigation Drawables:**
- `ic_nav_grade.xml` - Grade navigation icon
- `ic_nav_grade_selected.xml` - Selected grade icon
- `ic_nav_listening.xml` - Listening navigation icon
- `ic_nav_listening_selected.xml` - Selected listening icon
- `ic_nav_more.xml` - More navigation icon
- `ic_nav_more_selected.xml` - Selected more icon
- `ic_nav_team.xml` - Team navigation icon
- `ic_nav_team_selected.xml` - Selected team icon
- `ic_nav_toast.xml` - Toast navigation icon
- `ic_nav_toast_selected.xml` - Selected toast icon
- `ic_nav_word.xml` - Word navigation icon
- `ic_nav_word_selected.xml` - Selected word icon

**Navigation Selectors:**
- `navigator_toast_selector.xml` - Toast selector
- `navigator_grade_selector.xml` - Grade selector
- `navigator_listening_selector.xml` - Listening selector
- `navigator_more_selector.xml` - More selector
- `navigator_team_selector.xml` - Team selector
- `navigator_word_selector.xml` - Word selector

### Achievement Icons

**Crown/Rank Icons:**
- `ic_crown.xml` - Crown icon
- `ic_green_chrown.xml` - Green crown icon
- `ic_purle_chrown.xml` - Purple crown icon
- `ic_group_crown.xml` - Group crown icon

**Star Icons:**
- `ic_star.xml` - Star icon
- `ic_purple_star.xml` - Purple star icon
- `ic_yellow_star.xml` - Yellow star icon
- `home_star.xml` - Home star icon
- `$ic_yellow_star__0.xml` - Animated yellow star

### Action Icons

**Common Actions:**
- `ic_add_user.xml` - Add user icon
- `ic_delete.xml` - Delete icon
- `ic_edit.xml` - Edit icon
- `ic_share.xml` - Share icon
- `ic_setting.xml` - Settings icon
- `ic_search.xml` - Search icon
- `ic_close.xml` - Close icon
- `ic_back.xml` - Back icon

### Status Icons

**Status Indicators:**
- `ic_complete.xml` - Complete icon
- `ic_failed.xml` - Failed icon
- `ic_pass.xml` - Pass icon
- `ic_check.xml` - Check icon
- `ic_question.xml` - Question icon
- `ic_info.xml` - Info icon
- `ic_warning.xml` - Warning icon

---

## UI Component Structure

### Jetpack Compose Components

**Compose Activities:**
- `MainActivity$setComposeView` - Main activity with Compose view
- `FightResultActivity$initComposeView` - Fight result with Compose
- `CollectionQuizAnswerActivity$initComposeView` - Quiz answer with Compose
- `CollectionWordDescActivity$initComposeView` - Word description with Compose
- `WordListFragment$initComposeView` - Word list with Compose

**Compose Extensions:**
- `ComposeExtKt.java` - Compose extensions
- `core/p081ui/extensions/ComposeExtKt.java` - Core Compose extensions
- `extension/ComposeExtKt.java` - Additional Compose extensions

### Widget System

**Home Screen Widgets:**
- `english_small_toast_app_widget.xml` - Small toast widget
- `english_small_toast_app_widget_info.xml` - Widget configuration
- `item_event_notification_toast.xml` - Notification widget

**Widget Layouts:**
- `layout_splash.xml` - Splash screen layout
- Various glance layouts for widget system

---

## Color and Theme System

**Color Resources:**
- `values-night/colors.xml` - Dark theme colors
- `values/colors.xml` - Light theme colors
- `color/m3_card_ripple_color.xml` - Card ripple colors
- `color/m3_card_foreground_color.xml` - Card foreground colors

**Style Resources:**
- `values/styles.xml` - Main styles
- `values-night/styles.xml` - Dark theme styles
- `values-land/styles.xml` - Landscape styles
- `values-port/bools.xml` - Portrait booleans

---

## Shape and Background System

**Shape Drawables:**
- `shape_white_rectangle.xml` - White rectangle
- `shape_gray_rectangle.xml` - Gray rectangle
- `shape_green_rectangle.xml` - Green rectangle
- `shape_red_rectangle.xml` - Red rectangle
- `shape_brown_rectangle.xml` - Brown rectangle
- `shape_gold_round_rect.xml` - Gold rounded rectangle
- `shape_white_half_rectangle.xml` - White half rectangle
- `shape_fight_rectangle.xml` - Fight rectangle
- `shape_lottery_start.xml` - Lottery start shape

**Backgrounds:**
- `background_gradient_purple.xml` - Purple gradient background
- `shape_login_page_background.xml` - Login page background
- `shape_widget_spinner.xml` - Widget spinner background

---

## Image Assets

**WebP Images:**
- `clock_notify_icon.webp` - Clock notification icon
- `collection_tip_item.webp` - Collection tip item
- `fight_enter.webp` - Fight enter image
- `green_yellow_vs.webp` - Green vs yellow image
- `lottery_machine.webp` - Lottery machine
- `mock_head.webp` - Mock head image
- `notification.png` - Notification icon
- `rating_title.webp` - Rating title
- `report_item.webp` - Report item
- `report_title.webp` - Report title
- `share_bk.webp` - Share background
- `share_info.webp` - Share info
- `team_mission_rule.webp` - Team mission rule
- `team_tutorial_1.webp` - Team tutorial 1
- `team_tutorial_2.webp` - Team tutorial 2
- `team_tutorial_3.webp` - Team tutorial 3
- `test_ham.webp` - Test ham image
- `wip_item.webp` - WIP item

**PNG Images:**
- `inapp_close_button.png` - In-app close button
- `inapp_delete_button.png` - In-app delete button
- `ic_chef_selected.png` - Chef selected
- `ic_chef_unselected.png` - Chef unselected

---

## Other Assets

**Layouts:**
- `layout_large.html`, `layout_medium.html`, `layout_small.html` - Responsive layouts

**Audio:**
- `playVolume/` directory contains audio files

---

## Technical Stack

### Network Layer
- Retrofit2 for API calls
- OkHttp3 for HTTP client
- Kotlin coroutines for async operations

### Data Models
- `NetworkWord.java` - Word data model
- `NetworkWordSetInfoResponse.java` - Word set info
- `ResponseWords.java` - Word response
- `ResponseCollectionWord.java` - Collection word response

### Repository Pattern
- `NetworkImpl.java` - Network implementation
- `WordSetRepositoryImpl.java` - Word set repository
- `EnglishService.java` - API service interface

### UI Framework Stack
- **Primary:** Jetpack Compose (modern declarative UI)
- **Legacy:** XML layouts for widgets and some components
- **Animations:** Lottie (JSON-based animations)
- **Icons:** Vector drawables (XML) + WebP/PNG images
- **Theming:** Material Design 3 (M3) components

---

## Legal/Privacy Concerns

### Permissions
- Camera access for word scanner
- Calendar read/write (purpose unclear)
- Storage read/write (for saving images/data)
- Internet access (required for backend)
- Phone state read (for user identification)
- Ad ID tracking (Google Ad Services)

### Security
- Cleartext traffic enabled (`usesCleartextTraffic="true"`) - significant vulnerability
- No evidence of exposed API keys (better than other apps)

### Data Collection
- Firebase Analytics enabled
- AppsFlyer attribution tracking
- Appier SDK for push notifications and analytics

---

## Data Formats

### Icon Format (Self-Made)

**Format:** Android Vector Drawables (XML)

**Example - ic_toast.xml:**
```xml
<?xml version="1.0" encoding="utf-8"?>
<vector android:height="68.0dp" android:width="127.0dp" android:viewportWidth="127.0" android:viewportHeight="68.0"
  xmlns:android="http://schemas.android.com/apk/res/android">
    <path android:fillColor="#ffffff" android:pathData="M0,39.355a63.296,28.205 0,1 0,126.592 0a63.296,28.205 0,1 0,-126.592 0z" />
    <path android:fillColor="#ededed" android:pathData="M20.333,36.076a42.963,19.022 0,1 0,85.925 0a42.963,19.022 0,1 0,-85.925 0z" />
    <path android:fillColor="#ddaf78" android:pathData="M105.452,27.138L71.659,7.631C68.13,5.591 62.706,5.329 58.711,6.831..." />
    <path android:fillColor="#ffedbd" android:pathData="M107.984,31.126C112.005,28.81 111.985,25.039 107.938,22.704L71.659,1.754..." />
    <path android:fillColor="#f1d4a1" android:pathData="M31.036,29.81a3.675,2.042 0,1 0,7.351 0a3.675,2.042 0,1 0,-7.351 0z" />
</vector>
```

**Example - ic_star.xml:**
```xml
<?xml version="1.0" encoding="utf-8"?>
<vector android:height="24.0dp" android:width="24.0dp" android:viewportWidth="24.0" android:viewportHeight="24.0"
  xmlns:android="http://schemas.android.com/apk/res/android">
    <path android:fillColor="#896335" android:pathData="M17.9189,14.3201C17.6599,14.5711 17.5409,14.9341 17.5999,15.2901L18.4889,20.2101C18.5639,20.6271 18.3879,21.0491 18.0389,21.2901C17.6969,21.5401 17.2419,21.5701 16.8689,21.3701L12.4399,19.0601C12.2859,18.9781 12.1149,18.9341 11.9399,18.9291H11.6689C11.5749,18.9431 11.4829,18.9731 11.3989,19.0191L6.9689,21.3401C6.7499,21.4501 6.5019,21.4891 6.2589,21.4501C5.6669,21.3381 5.2719,20.7741 5.3689,20.1791L6.2589,15.2591C6.3179,14.9001 6.1989,14.5351 5.9399,14.2801L2.3289,10.7801C2.0269,10.4871 1.9219,10.0471 2.0599,9.6501C2.1939,9.2541 2.5359,8.9651 2.9489,8.9001L7.9189,8.1791C8.2969,8.1401 8.6289,7.9101 8.7989,7.5701L10.9889,3.0801C11.0409,2.9801 11.1079,2.8881 11.1889,2.8101L11.2789,2.7401C11.3259,2.6881 11.3799,2.6451 11.4399,2.6101L11.5489,2.5701L11.7189,2.5001H12.1399C12.5159,2.5391 12.8469,2.7641 13.0199,3.1001L15.2389,7.5701C15.3989,7.8971 15.7099,8.1241 16.0689,8.1791L21.0389,8.9001C21.4589,8.9601 21.8099,9.2501 21.9489,9.6501C22.0799,10.0511 21.9669,10.4911 21.6589,10.7801L17.9189,14.3201Z" />
</vector>
```

**Icon Format Summary:**
- **File Type:** XML (Vector Drawable)
- **Structure:** `<vector>` root element with `path` children
- **Attributes:** `android:height`, `android:width`, `android:viewportWidth`, `android:viewportHeight`, `android:fillColor`, `android:pathData`
- **Path Data:** SVG-like path commands (M, L, C, Z, etc.)
- **Color:** Hex color codes (e.g., `#ffffff`, `#ddaf78`)
- **Resolution:** Scalable vector graphics (no pixelation)

**Additional Icon Formats:**
- WebP images (complex graphics)
- PNG images (legacy support)
- Animated vector drawables (simple animations)

---

### Word Dataset Format (NOT Self-Made)

**Conclusion:** Word datasets are NOT self-made locally. They are fetched from server APIs.

**Data Source:** Server API endpoints (EnglishService.java)

**API Response Model - NetworkWord.java:**

```java
public final class NetworkWord {
    @SerializedName("Category")
    private final String category;

    @SerializedName("Cefr")
    private final String cefr;

    @SerializedName("ChineseCategory")
    private final String chineseCategory;

    @SerializedName("EnglishSentences")
    private final List<String> englishSentences;

    @SerializedName("Inflections")
    private final List<NetworkWordInflection> inflections;

    @SerializedName("KK")
    private final String kk;

    @SerializedName("MandarinSentences")
    private final List<String> mandarinSentences;

    @SerializedName("SentenceSoundFiles")
    private final List<String> sentenceSoundFiles;

    @SerializedName("Sequence")
    private final int sequence;

    @SerializedName("SpeechSoundFile")
    private final String speechSoundFile;

    @SerializedName("SupNotes")
    private final List<String> supNotes;

    @SerializedName("Text")
    private final String text;

    @SerializedName("Translations")
    private final String translations;

    @SerializedName("Type")
    private final String type;
}
```

**JSON Response Format (from server):**
```json
{
  "Sequence": 1,
  "Type": "noun",
  "Text": "example",
  "Translations": "範例",
  "Category": "general",
  "ChineseCategory": "一般",
  "SpeechSoundFile": "https://server.com/audio/example.mp3",
  "Cefr": "A1",
  "Kk": "/ɪɡˈzæmpəl/",
  "EnglishSentences": [
    "This is an example.",
    "For example, you can do this."
  ],
  "MandarinSentences": [
    "這是一個範例。",
    "例如，你可以這樣做。"
  ],
  "SentenceSoundFiles": [
    "https://server.com/audio/sentence1.mp3",
    "https://server.com/audio/sentence2.mp3"
  ],
  "SupNotes": [
    "Usage note",
    "Grammar note"
  ],
  "Inflections": [
    {
      "form": "examples",
      "type": "plural"
    }
  ]
}
```

**Word Dataset Format Summary:**
- **Format:** JSON (from server API)
- **Fields:**
  - Text: English word
  - Translations: Chinese translation
  - Category: Word category
  - ChineseCategory: Chinese category name
  - Type: Part of speech (noun, verb, etc.)
  - Cefr: CEFR level (A1, A2, B1, B2, C1, C2)
  - KK: KK phonetic transcription
  - SpeechSoundFile: URL to pronunciation audio
  - EnglishSentences: List of example sentences in English
  - MandarinSentences: List of example sentences in Chinese
  - SentenceSoundFiles: URLs to sentence audio files
  - SupNotes: Supplementary notes
  - Inflections: Word inflection forms
  - Sequence: Word sequence number

**No Local Word Database:**
- No `.db` or `.sqlite` files found in app assets
- No embedded vocabulary database
- No local word data storage files
- All word data fetched from server APIs

---

## Gamification Logic

### 1. Fight/Battle Mode

**Score Calculation (Local):**
- File: `FightHelper.java`
- Logic: Maps remaining answer time to points
  - 0.1-0.5s → 45 points
  - 0.6s → 46 points
  - 0.7-0.8s → 47 points
  - 0.9-1.0s → 48 points
  - 1.1-1.2s → 49 points
  - 1.3-1.4s → 50 points
  - 1.5s → 51 points
  - ... (gradual increase)
  - 9.5s → 95 points
  - 9.6-10.0s → 100 points
- Faster answers = more points

**Fight Statistics (Local):**
- File: `FightUseCase.java`
- Operations:
  - `sumFightScore(int score)` - accumulates fight score
  - `fightSumScore()` - gets total fight score
  - `fightStreakAgain()` - increments fight win streak
  - `fightStreak()` - gets fight win streak
  - `clearFightStreak()` - resets fight win streak
- Storage: LocalSharedPreferences

**Server Operations (Fight):**
- `reportStatic()` - reports fight statistics to server
  - Parameters: answerSheetList, fightStatic, totalQuestions, answeredQuestions, correctQuestions, timeSpentOnGame, rivalRank
- `getBattleSeasonRankingBoard()` - gets season ranking board from server
- `getBattleSeasonDailyRankingBoard()` - gets daily ranking board from server
- `getPersonalSeasonRecord()` - gets personal season record from server
- `addSeasonStar(int)` - adds season stars to user account (server)
- `showRankSummary()` - shows rank summary (local + server)

---

### 2. Winning Streak System

**Tracking Events (Analytics):**
- File: `WinningStreakEvent.java`
- Events tracked:
  - `toast_streak` - toast streak event
  - `toast_streak_confirm` - confirm streak (parameter: is)
  - `toast_streak_share` - share streak
  - `toast_streak_shield` - streak shield (parameter: is)
  - `toast_streak_shield_confirm` - confirm shield
  - `toast_streak_tutorial` - tutorial event
  - `toast_streak_tutoria_next` - tutorial next
  - `toast_streak_tutoria_confirm` - tutorial confirm
  - `widget_streak_popup_show` - widget popup show
  - `widget_streak_popup_click` - widget popup click

**Shield Mechanism:**
- Toast streak shield appears to be a protection mechanism for maintaining streak
- Tracked separately from base streak

---

### 3. Daily Missions

**Mission Types (from DailyMissionEvent.java):**
- `daily_word` - daily word mission
- `battle` - battle mode mission
- `toast_ingredients` - toast ingredients collection mission

**Tracking Events:**
- `DailyMission_GetReward_click` - get reward click
  - States: `get` (can get), `done` (already got), `undone` (cannot get), `popup` (complete mission popup)
- `DailyMission_GoToRank_click` - go to ranking click
  - States: `get` (can get), `done` (already got)
- `DailyMission_GoToMission_click` - go to mission click
  - Targets: `daily_word`, `battle`, `toast_ingredients`
- `DailyMission_GoToMission_click` - go to hint click

---

### 4. Prize/Capsule System

**Lotto Star Random Generation (Local):**
- File: `PrizeUseCase.java`
- Logic: Random number 0-999 maps to star count
  - 0-350 (35.1%) → 1 star
  - 350-800 (45.1%) → 5 stars
  - 800-955 (15.5%) → 10 stars
  - 955-985 (3.0%) → 50 stars
  - 986-999 (1.4%) → 100 stars

**Server Operations (Prize):**
- `getMyPrize()` - gets user's prizes from server
- `addPrize()` - adds prize to user account (server)
- `digestionPrize(id)` - digests/uses prize (server)
- `digestionCapsule(id)` - digests capsule to get avatar frame (server)
  - Returns: AvatarFrame (id, description, imageUrl, accepted, using, displayName)

---

### 5. Life/Heart System

**Life Info (Local + Server):**
- File: `LifeUseCase.java`
- Storage: LifeRepository (syncs with server)
- Flow-based state management

**Operations:**
- `getCurrentLifeInfo()` - gets current life info (syncs with server)
- `removeLife()` - removes one life (syncs with server)
- `addLife(AddLifeReason)` - adds life with reason (syncs with server)
  - Reasons: ReviewWords (default), etc.
- `addLifeMember(memberId)` - adds life to team member (server)

---

### 6. Collection/Progress System

**Server Operations (Collection):**
- File: `CollectionUseCase.java`
- `getProgress(levelId)` - gets progress for specific level (server)
  - Returns: Level data + stages + reviewExam + clozeStages + clozeStageUnlockedAt
- `getUserMapCollectionProgression()` - gets user's map collection progression (server)
- `getUserLearningGoal()` - gets user's learning goal (server)
- `getUserTestAndGoalState()` - gets test and goal state (server)
  - States: GoalSet, NoGoalGrade, NoGoalNoGrade
- `getClozeCollectionResource()` - gets cloze collection resource (server)
- `getUserMapCollectionTotalWords()` - gets total words in user's collection (server)
- `getMapCollectionLevelList()` - gets map collection level list
- `getUserMapCollectionList()` - gets user's map collection list
- `getCollectionStageWords(levelId, isCheckService)` - gets words for collection stage
- `getCollectionStageMultiTestWords(levelId, isCheckService)` - gets multi-test words for stage
- `getCurrentCollectionItemModel()` - gets current collection item model
- `getMapCollectionStatusByUserLevel(userLevel)` - gets collection status by user level
- `hasToastProgress()` - checks if user has toast progress

**Collection Progress States:**
- Complete - toast completed
- OnProgressOrUnlock - in progress or unlocked

---

### 7. Avatar Frame System

**Avatar Frame Types:**
- Mission avatar frame - from daily missions
- Rank battle avatar frame - from battle rankings

**Server Operations (Avatar):**
- File: `ProfileUseCase.java`
- `setMyMissionAvatarFrame()` - sets mission avatar frame (server)
- `setMyRankBattleAvatarFrame()` - sets rank battle avatar frame (server)
- `dismissMyAvatarFrame()` - dismisses avatar frame (server)

**Avatar Frame Data:**
- id - frame identifier
- description - frame description
- imageUrl - frame image URL
- accepted - whether accepted
- using - whether currently in use
- displayName - display name

---

## Server Operations Summary

### Operations Requiring Server Connection:

**Fight/Battle:**
- Report fight statistics
- Get season ranking board
- Get daily ranking board
- Get personal season record
- Add season stars

**Prize/Capsule:**
- Get my prizes
- Add prize
- Digest prize
- Digest capsule (get avatar frame)

**Life/Heart:**
- Sync life info
- Remove life
- Add life
- Add life to team member

**Collection/Progress:**
- Get level progress
- Get user map collection progression
- Get user learning goal
- Get cloze collection resource
- Get user map collection total words
- Get collection stage words
- Get collection stage multi-test words

**Avatar Frame:**
- Set mission avatar frame
- Set rank battle avatar frame
- Dismiss avatar frame

**Daily Mission:**
- Get daily mission status (server-side tracking)
- Claim mission rewards (server)

### Local-Only Operations:

**Fight/Battle:**
- Calculate score from remaining time
- Accumulate fight score
- Track fight win streak
- Clear fight win streak

**Prize/Capsule:**
- Generate random lotto star count

**Collection/Progress:**
- Map collection level list (local cache)
- Current collection item model (local)
- Map collection status by user level (local)
- Has toast progress check (local)

**Analytics/Tracking:**
- All tracking events (WinningStreakEvent, DailyMissionEvent, etc.) - sent to analytics servers

---

## What Cannot Be Verified

- Exact server URL (base URL not found in decompiled code)
- Total dataset size on server
- Offline mode implementation (if any)
- Background sync mechanism details
- Data compression or optimization on server
- Exact animation timing and playback logic
- User interaction handling for animations
- Dynamic asset loading logic
- Animation state management
- Theme switching implementation details
- Widget update mechanisms
- Actual JSON response examples from server (only model structure available)
- Server-side gamification logic (how missions are assigned, how rewards are calculated server-side)
- Season duration and reset logic
- Shield mechanism implementation details
- Avatar frame unlock conditions

**Reason:** Server-side implementation details and compiled Kotlin/Java code require deeper reverse engineering beyond static analysis.

---

## Comprehensive App Experience Flow

### User Journey Overview

The English Knowledge King app (com.cmoney.englishwidget) combines English vocabulary learning with gamification elements including battles, streaks, daily missions, and collection progress. Below is the verified flow based on code analysis.

---

### 1. App Launch & Authentication

**Initial Flow:**
- App starts with MainActivity
- User authentication via:
  - Facebook SDK integration (from AndroidManifest.xml)
  - Firebase for authentication
  - LocalSharedPreferences for session persistence

**Subscription Check:**
- SubscriptionViewModel checks subscription status
- Google Play Billing for in-app purchases
- Subscription data stored locally

---

### 2. Main Learning Flow

**Word Collection (Map-based Progress):**
- User navigates through map-based word collection
- CollectionUseCase manages progression:
  - `getUserMapCollectionProgression()` - fetches from server
  - `getProgress(levelId)` - gets specific level progress
  - Progress states: Complete, OnProgressOrUnlock

**Learning Modes:**
- **Daily Word** - One word per day from daily mission
- **Battle Mode** - Real-time vocabulary battles
- **Toast Ingredients** - Collect ingredients to build "toast" (vehicle/car theme)
- **Cloze Tests** - Fill-in-the-blank exercises
- **Review Words** - Review previously learned words

**Word Data Flow:**
- Words fetched from server via EnglishService API:
  - `getAllEnglishWords()` - full word list
  - `getMapCollectionWord()` - collection-specific words
  - `getPlacementTestWords()` - placement test words
- NetworkWord model structure: Text, Translations, CEFR level, Sentences, Inflections, IPA pronunciation
- No local word database - all data server-fetched

---

### 3. Battle/Fight Mode Flow

**Battle Initiation:**
- User enters battle mode
- FightUseCase initializes:
  - `fightSumScore()` - gets current total score
  - `fightStreak()` - gets current win streak

**Answer Phase:**
- Question presented (QuestionModel)
- User answers within time limit
- FightHelper.scoreCalculateMapping() calculates points:
  - 0.1-0.5s → 45 points
  - 0.6s → 46 points
  - ...gradual increase...
  - 9.6-10.0s → 100 points
  - Faster answers = more points

**Score Accumulation:**
- `sumFightScore(int score)` - accumulates points
- If correct: `fightStreakAgain()` - increments win streak
- If incorrect: `clearFightStreak()` - resets streak

**Battle Completion:**
- `reportStatic()` - sends to server:
  - answerSheetList
  - totalQuestions
  - answeredQuestions
  - correctQuestions
  - timeSpentOnGame
  - rivalRank

**Ranking Updates:**
- `getBattleSeasonRankingBoard()` - fetches season rankings
- `getBattleSeasonDailyRankingBoard()` - fetches daily rankings
- `getPersonalSeasonRecord()` - fetches user's season record
- `addSeasonStar(int)` - awards season stars based on performance

---

### 4. Winning Streak System

**Streak Tracking:**
- Toast streak tracked locally and via analytics
- WinningStreakEvent events fired:
  - `toast_streak` - streak achieved
  - `toast_streak_confirm` - user confirms
  - `toast_streak_share` - user shares
  - `toast_streak_shield` - shield activated
  - `toast_streak_shield_confirm` - shield confirmed
  - `widget_streak_popup_show` - widget popup
  - `widget_streak_popup_click` - widget interaction

**Shield Mechanism:**
- Shield protects streak from being lost
- Tracked separately from base streak
- Activation and confirmation tracked via events

---

### 5. Daily Missions Flow

**Mission Assignment:**
- Three mission types tracked via DailyMissionEvent:
  - `daily_word` - complete daily word learning
  - `battle` - participate in battle mode
  - `toast_ingredients` - collect toast ingredients

**Mission Progress:**
- User completes mission activities
- Progress tracked server-side
- States: `get` (can claim), `done` (already claimed), `undone` (incomplete), `popup` (completion popup)

**Reward Claiming:**
- `DailyMission_GetReward_click` - user claims reward
- Rewards processed server-side
- May include: stars, prizes, capsules

**Navigation:**
- `DailyMission_GoToMission_click` - navigate to mission
- `DailyMission_GoToRank_click` - navigate to rankings
- `DailyMission_GoToMission_click` - navigate to hints

---

### 6. Prize/Capsule System

**Lotto Star Generation:**
- PrizeUseCase.getLottoStar() generates random star count:
  - Random number 0-999
  - 0-350 (35.1%) → 1 star
  - 350-800 (45.1%) → 5 stars
  - 800-955 (15.5%) → 10 stars
  - 955-985 (3.0%) → 50 stars
  - 986-999 (1.4%) → 100 stars

**Prize Management:**
- `getMyPrize()` - fetches user's prizes from server
- `addPrize()` - adds prize to account (server)
- `digestionPrize(id)` - uses/digests prize (server)

**Capsule System:**
- Capsules contain avatar frames
- `digestionCapsule(id)` - opens capsule to get avatar frame
- Returns AvatarFrame data:
  - id, description, imageUrl
  - accepted, using, displayName

**Avatar Frame Types:**
- Mission avatar frame - from daily missions
- Rank battle avatar frame - from battle rankings

**Avatar Frame Management:**
- `setMyMissionAvatarFrame()` - equip mission frame (server)
- `setMyRankBattleAvatarFrame()` - equip battle frame (server)
- `dismissMyAvatarFrame()` - dismiss frame (server)

---

### 7. Life/Heart System

**Life Management:**
- LifeUseCase manages heart/life system
- LifeRepository syncs with server
- Flow-based state management (Kotlin Flow)

**Life Operations:**
- `getCurrentLifeInfo()` - fetch current life count (syncs with server)
- `removeLife()` - consume one life (syncs with server)
- `addLife(AddLifeReason)` - add life with reason:
  - Default: ReviewWords
  - Other reasons available
- `addLifeMember(memberId)` - send life to team member (server)

**Life Consumption:**
- Lives consumed when:
  - Starting battles
  - Taking tests
  - Other premium activities

**Life Recovery:**
- Lives added through:
  - Reviewing words
  - Team member gifts
  - Time-based recovery (if implemented server-side)

---

### 8. Collection/Progress Flow

**Progress Tracking:**
- CollectionUseCase manages all collection progress
- Server-side progression tracking

**Level Progress:**
- `getProgress(levelId)` - fetches level data:
  - Stages
  - Review exams
  - Cloze stages
  - Cloze stage unlock timestamp
- Progress states: Complete, OnProgressOrUnlock

**Collection Resources:**
- `getClozeCollectionResource()` - fetches cloze test resources
- `getUserMapCollectionTotalWords()` - total words in collection
- `getMapCollectionLevelList()` - available levels
- `getUserMapCollectionList()` - user's unlocked collections

**Stage Words:**
- `getCollectionStageWords(levelId, isCheckService)` - words for stage
- `getCollectionStageMultiTestWords(levelId, isCheckService)` - multi-test words

**Goal Setting:**
- `getUserLearningGoal()` - fetches learning goal
- `getUserTestAndGoalState()` - combined state:
  - GoalSet - has goal and grade
  - NoGoalGrade - has grade, no goal
  - NoGoalNoGrade - neither

---

### 9. Widget Integration

**Widget Types:**
- EnglishBgToastAppWidget - background toast widget
- EnglishSmallToastAppWidget - small toast widget
- EnglishAppBgWidget - app background widget

**Widget Updates:**
- WidgetProvider manages updates
- Toast-themed widgets show:
  - Current streak
  - Daily word
  - Progress indicators

**Widget Interactions:**
- `widget_streak_popup_show` - streak popup
- `widget_streak_popup_click` - user interaction
- Deep links to main app features

---

### 10. UI & Animation Flow

**UI Framework:**
- Jetpack Compose for modern UI
- XML layouts for legacy components
- Material Design components

**Animation System:**
- Lottie JSON animations for:
  - Toast vehicles (horse_toast.json, car animations)
  - Gotcha animations
  - Success/failure feedback

**Icon System:**
- Android Vector Drawables (XML format):
  - ic_toast.xml - toast icon
  - ic_star.xml - star icon
  - Various UI icons

**Color & Theme:**
- Material Design color system
- Toast/vehicle theme throughout
- Dynamic theming support

---

### 11. Data Sync Flow

**Server Synchronization:**
- NetworkImpl handles API calls
- EnglishService defines endpoints
- Retrofit for HTTP requests

**Caching Strategy:**
- ClozeCollectionResource cached locally
- CollectionResource cached locally
- Progress data synced with server
- SharedPreferences for local settings

**Offline Handling:**
- Local storage for basic functionality
- Server sync when connection available
- Error handling for network failures

---

### 12. Analytics & Tracking

**Event Tracking:**
- All gamification events tracked:
  - WinningStreakEvent
  - DailyMissionEvent
  - BattleEvent
  - RankEvent
  - QuizEvent
  - LifeEvent
  - NewCollectionEvent
  - TutorialEvent
  - GroupEvent

**Analytics Providers:**
- Firebase Analytics
- Appier Aiqua SDK
- Custom event tracking via TrackEvent base class

---

### 13. Complete User Experience Summary

**New User Flow:**
1. App launch → Authentication
2. Placement test → Determine level
3. Map collection → Start first level
4. Daily word → Learn one word
5. Battle mode → Compete with AI/players
6. Earn streaks → Build winning streak
7. Complete missions → Claim rewards
8. Collect ingredients → Build toast
9. Unlock levels → Progress through map
10. Earn prizes → Open capsules for avatar frames

**Returning User Flow:**
1. App launch → Auto-login
2. Check daily missions → Complete tasks
3. Battle mode → Maintain streak
4. Review words → Earn lives
5. Check rankings → View season progress
6. Claim rewards → Open prizes/capsules
7. Customize avatar → Equip frames

**Gamification Loop:**
- Learn words → Earn points → Unlock levels → Complete missions → Get rewards → Customize avatar → Compete in battles → Earn streaks → Repeat

---

## Conclusion

**Dataset Storage:** NOT local. All word data is fetched from server APIs.

**Dataset Separation:**
- Word Sets: By word set ID
- Toast Words: By level
- Placement Words: By level and question count
- Wrong Words: By user and time range
- Cloze Quiz: By level and stage
- Grade Data: By grade
- Listening Test: By difficulty and paper

**Cache Strategy:** No local caching for word data (Cache-Control: no-store)

**Data Flow:** Server API → App UI → User Progress → Server API

**UI Framework:** Jetpack Compose with XML layouts for widgets

**Animation System:** Lottie (JSON) + ZIP files for complex animations

**Icon System:** Vector drawables (XML) + WebP/PNG images

**Toast System:** Extensive toast-themed UI components with 20+ icons and 10+ animations

**Vehicle Theme:** Car-related animations (no fish icons found)

**Architecture:** Modern Compose-based UI with Material Design 3 components

This architecture ensures users always get the latest word data from the server, but requires internet connection for most features.
