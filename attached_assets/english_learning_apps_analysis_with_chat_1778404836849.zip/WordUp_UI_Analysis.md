# WordUp App - UI Sections Analysis

## Overview
This document explains the verified files and logic for each main page UI section in the WordUp app, based on actual code analysis from the compiled native library.

---

## Analysis Method

**How this was verified:**
1. Extracted ARM architecture APK from XAPK split APKs
2. Located Flutter native library: `lib/armeabi-v7a/libapp.so`
3. Used `strings` command to extract embedded source file paths and string literals
4. This revealed the actual Dart file structure and component names

**Note:** Flutter compiles Dart to native machine code (AOT), embedding source file paths and strings in the binary. This is a standard reverse engineering technique for Flutter apps.

---

## UI Section: Today's Reviews

### Related Files
- **Main file:** `package:wordup_app/src/features/wordup/challenges/presentation/reviews/reviews_page.dart`

### What It Contains
- Reviews page UI component
- Located in the "challenges" feature area
- Part of the presentation layer (UI)

### Logic Behind It
Based on file structure:
- Reviews are organized as a "challenge" feature
- The page handles displaying review content
- Likely uses the local database (my_wordup_v2.db) to fetch words for review
- The `words` table has a `learnStateInt` field which likely tracks review status
- Reviews may use spaced repetition algorithm (common in language learning apps)

**Data source:** SQLite database with `words` table containing `learnStateInt` field for tracking review state

---

## UI Section: Knowledge Map

### Related Files
- **Main file:** `package:wordup_app/src/features/zann_vocabulary/home/presentation/widgets/vocabulary_home_knowledge_map_section.dartr`
- **Module:** `zann_vocabulary`

### What It Contains
- Knowledge map section widget
- Located in the vocabulary module's home page
- Part of the presentation layer (UI component)

### Data Sources

**1. Words and Basic Data (Local Database)**
- **Source:** SQLite database `my_wordup_v2.db`
- **Table:** `words`
- **Fields:**
  - `text` - The word itself
  - `otherForms` - Word forms (plural, past tense, etc.)
  - `britishPhonetic` - UK IPA pronunciation
  - `americanPhonetic` - US IPA pronunciation
  - `primaryMeaning` - Primary definition
  - `rank` - Word frequency ranking
  - `personalRank` - User-specific ranking
  - `learnStateInt` - Learning progress state

**2. Translations (Online)**
- **Service:** `_fetchTranslation@2097216615r`
- **Service:** `_fetchSensTransaltionOnline@2398258767`
- **Logic:** Translations fetched from backend API when online
- **Fallback:** May cache translations locally for offline use

**3. AI Images (Network)**
- **Library:** `cached_network_image` (from strings)
- **Service:** `_loadImage@1687151381`
- **Logic:** Images fetched from network and cached locally
- **Storage:** Likely cached in device storage after first download

**4. Speech/Pronunciation (Device TTS)**
- **Package:** `flutter_tts` (standard Flutter TTS plugin)
- **Permission:** `RECORD_AUDIO`, `MODIFY_AUDIO_SETTINGS`, `AUDIO_CAPTURE`
- **Service:** Android TTS (text-to-speech) service
- **Files:**
  - `package:flutter_tts/flutter_tts.dartr`
  - `LexiSpeakingPage` (from strings)
  - `setSpeechRate` (from strings)
  - `_ensureSpeechReady@2512031904` (from strings)
  - `speechLexi` (from strings)
  - `speechByVoice` (from strings)
- **Audio Management:** `AndroidAudioManager`, `com.ryanheise.audio_session`
- **Logic:** Uses flutter_tts plugin which wraps device's built-in TTS engine
- **Data Source:** IPA phonetics from database guide TTS pronunciation
- **Features:** Speech rate control, voice selection, online audio playback (`playOnlineAudio`)

**5. User Notes (Synced)**
- **Service:** `_downloadAndParseUserNotes@2628194402`
- **Sync Endpoint:** `https://sync.wrdp.app` (from strings)
- **Logic:** User notes downloaded and parsed from backend
- **Storage:** Stored locally in database or file system

### Data Flow

**Primary Flow (Online):**
1. User taps word in Knowledge Map
2. App queries local database for basic word data (text, phonetics, forms)
3. App fetches translations from backend API (`_fetchTranslation`)
4. App loads AI illustration images from network (`_loadImage`)
5. Images cached locally for future use
6. User can play pronunciation using device TTS
7. User notes synced from `https://sync.wrdp.app`

**Offline Flow:**
1. User taps word in Knowledge Map
2. App uses `loadOfflineWords` function
3. Basic data from local database (always available)
4. Cached images (if previously downloaded)
5. Cached translations (if previously fetched)
6. TTS still works (device feature, not network-dependent)

**Sync Flow:**
1. App periodically syncs with `https://sync.wrdp.app`
2. Downloads updated word data, translations, images
3. Uploads user progress and notes
4. Updates local database with synced data

### Logic Behind It
Based on file structure:
- Knowledge map is a section within the vocabulary module
- Hybrid approach: local database + online API
- Offline-first design with sync capability
- Images and translations fetched on-demand and cached
- Device TTS for pronunciation (no network needed)
- User data synced to cloud for cross-device access

---

## UI Section: Practice with Lexi

### Related Files

**Vocabulary Mode:**
- **Page:** `package:wordup_app/src/features/wordup/chat/presentation/pages/lexi_vocabulary_page.dart`
- **Route:** `/lexi_vocabulary`
- **Asset:** `assets/images/Lexi/Lexi-Vocabulary.png`

**Writing Mode:**
- **Page:** `package:wordup_app/src/features/wordup/chat/presentation/pages/lexi_writing_page.dart`
- **Controller:** `package:wordup_app/src/features/wordup/chat/presentation/controllers/lexi_writing_controller.dart`
- **Route:** `/lexi_writing`
- **Result Route:** `/lexi_writing_result`
- **Asset:** `assets/images/Lexi/Lexi-Writing.png`

**Speaking Mode:**
- **Page:** `package:wordup_app/src/features/wordup/chat/presentation/pages/lexi_speaking_page.dart`
- **Functions:** `speechLexi`, `speechByVoice`, `lexiSpeech`
- **Asset:** `assets/images/Lexi/Lexis-Choice.png`

**Shared Components:**
- **Chat data:** `package:wordup_app/src/features/shared/chat/data/models/word_chat.dart`
- **Input widget:** `package:wordup_app/src/features/shared/chat/presentation/widgets/chat_input_section.dart`
- **Voice chat:** `package:wordup_app/src/features/wordup/chat/presentation/pages/voice_chat_page.dart`
- **Explain params:** `package:wordup_app/src/features/shared/chat/data/models/lexi_explain_params.dart`
- **Explain page:** `LexiExplainChatPage`
- **Explain functions:** `lexiExplain`, `lexiExplainParams`
- **Home widget:** `package:wordup_app/src/features/wordup/home/presentation/widgets/home_practice_lexi_widget.dart`
- **Streak counter:** `LexiDayStreakCounter`

### What It Contains
- Three practice modes: Vocabulary, Writing, Speaking
- Lexi writing practice page with controller
- Lexi vocabulary practice page
- Lexi speaking practice page
- Chat data models for word conversations
- Chat input section widget
- Voice chat page for spoken practice
- Lexi explanation feature with parameters
- Day streak tracking for practice consistency

### Logic Behind It

**Vocabulary Mode:**
- Dedicated vocabulary practice page
- Uses shared chat system for word explanations
- LexiExplainParams for customizing explanations
- Likely displays words with definitions and examples

**Writing Mode:**
- Controller pattern for state management (LexiWritingController)
- Writing practice with result tracking (/lexi_writing_result route)
- Uses chat input system for user responses
- Likely evaluates writing quality and provides feedback

**Speaking Mode:**
- Voice-based practice (speechLexi, speechByVoice, lexiSpeech)
- Uses TTS for Lexi's speech output
- Uses speech recognition for user input
- Audio permissions for recording user speech

**Shared Features:**
- All modes use shared chat infrastructure
- LexiExplain feature for word explanations (lexiExplain, LexiExplainChatPage)
- Day streak tracking (LexiDayStreakCounter) for practice consistency
- Home widget integration (HomePracticeWithLexiWidget)

**Audio permissions:** `RECORD_AUDIO`, `MODIFY_AUDIO_SETTINGS`, `AUDIO_CAPTURE` - for voice chat and speech recognition functionality

---

## UI Section: Fantasy Chat

### Related Files

**Celebchat Module (zann_celebchat):**
- **Controller:** `package:wordup_app/src/features/zann_celebchat/chat/presentation/controllers/chat_controller_celebchat.dart`
- **Service:** `package:wordup_app/src/features/zann_celebchat/chat/data/services/celebchat_service.dart`
- **Repository:** `package:wordup_app/src/features/zann_celebchat/chat/data/services/celebchat_repository.dart`
- **Database:** `package:wordup_app/src/features/zann_celebchat/chat/data/services/celebchat_database.dart`
- **Home page:** `package:wordup_app/src/features/zann_celebchat/home/presentation/pages/home_page_celebchat.dart`
- **Chat threads page:** `package:wordup_app/src/features/zann_celebchat/chat/presentation/pages/chat_threads_page.dart`
- **Reminder service:** `CelebchatReminderService`, `package:wordup_app/src/features/zann_celebchat/chat/data/services/celebchat_reminder_service.dart`
- **Points system:** `CelebchatPoints`, `package:wordup_app/src/features/zann_celebchat/chat/presentation/mixins/celebchat_points_mixin.dart`

**Data Models:**
- **Chat message:** `package:wordup_app/src/features/zann_celebchat/chat/data/models/chat_message.dart`
- **Chat thread:** `package:wordup_app/src/features/zann_celebchat/chat/data/models/chat_thread.dart`
- **Pending message:** `package:wordup_app/src/features/zann_celebchat/chat/data/models/pending_message.dartr`
- **Chat tip:** `package:wordup_app/src/features/zann_celebchat/chat/data/models/chat_tip.dart`
- **Celebrity opener:** `package:wordup_app/src/features/zann_celebchat/chat/data/models/celebrity_opener.dart`

**Shared Chat Infrastructure:**
- **Base controller:** `ChatControllerCelebChat` extends `ChatController` & `MessageSaver` (from mixin name)
- **Chat input:** `package:wordup_app/src/features/shared/chat/presentation/widgets/chat_input_section.dart`
- **Message saver:** `package:wordup_app/src/features/shared/chat/presentation/mixins/chat_controller_message_saver.dart`

**Assets:**
- `assets/images/onboarding/celebchat/chat.png`
- `assets/images/onboarding/celebchat/tips.png`
- `assets/images/onboarding/celebchat/splash_image.png`
- `assets/icons/app/zann_celebchat.png`

### What It Contains
- Celebrity chat feature (zann_celebchat module)
- Dedicated chat controller for celebchat
- Separate database for celebchat conversations
- Points/gamification system (CelebchatPoints)
- Reminder service for celebchat notifications
- Chat thread management
- Celebrity character openers
- Chat tips and guidance

### Logic Behind It

**Chat Infrastructure:**
- Celebchat has its OWN controller (ChatControllerCelebChat)
- Celebchat has its OWN database (CelebChatDatabase)
- Celebchat has its OWN service and repository
- BUT Celebchat EXTENDS the shared ChatController and MessageSaver
- This means: **Shared base infrastructure + separate implementation**

**Comparison with Lexi:**
- **Shared:** Both use ChatController base class and MessageSaver mixin
- **Shared:** Both use chat_input_section.dart for input
- **Different:** Lexi uses LexiWritingController, Celebchat uses ChatControllerCelebChat
- **Different:** Lexi uses shared database, Celebchat has separate CelebChatDatabase
- **Different:** Celebchat has points system, Lexi has streak counter

**AI Chat Engine:**
- **API endpoints found:**
  - `https://sync.wrdp.app` - Sync endpoint
  - `https://friends.wrdp.app` - Friends endpoint
  - `https://auth.wordupapp.co` - Authentication endpoint
  - `/api/generate` - API generate endpoint (likely for AI responses)
- **Server communication:**
  - `ApiServerManager` - Manages API server connections
  - `fetchFromServerAndCache` - Fetches data from server and caches
  - `sendActionsToServer` - Sends user actions to server
  - `HttpClientAdapter` - HTTP client for API calls
- **Conclusion:** AI chat responses come from server APIs, not local AI models

**Gamification:**
- Celebchat has points system (CelebchatPoints, CelebchatPointsMixin)
- Celebchat has reminder service for engagement
- Lexi has streak counter for practice consistency

**Module integration:** Part of the Zann ecosystem with its own dedicated infrastructure

---

## UI Section: Lessons

### Related Files

**Controllers:**
- **Main controller:** `package:wordup_app/src/features/wordup/lessons/presentation/controllers/lessons_controller.dart`
- **Questions controller:** `package:wordup_app/src/features/wordup/lessons/presentation/controllers/lesson_questions_controller.dart`
- **Answer controller:** `package:wordup_app/src/features/wordup/lessons/presentation/controllers/answer_questions_controller.dart`
- **Question controller:** `package:wordup_app/src/features/wordup/lessons/presentation/controllers/question_controller.dart`

**Pages:**
- **Lessons page:** `package:wordup_app/src/features/wordup/lessons/presentation/pages/lessons_page.dart`
- **Questions page:** `package:wordup_app/src/features/wordup/lessons/presentation/pages/lesson_questions_page.dartr`
- **Answer page:** `package:wordup_app/src/features/wordup/lessons/presentation/pages/answer_questions_page.dartr`
- **Question page:** `package:wordup_app/src/features/wordup/lessons/presentation/pages/question_page.dartr`

**Widgets:**
- **Listen widget:** `package:wordup_app/src/features/wordup/lessons/presentation/widgets/listen_widget.dart`
- **Translation widget:** `package:wordup_app/src/features/wordup/lessons/presentation/widgets/pick_translation_question_widget.dart`
- **Progress widget:** `package:wordup_app/src/features/wordup/lessons/presentation/widgets/answer_quetsion_progress_widget.dart`
- **Category widget:** `package:wordup_app/src/features/wordup/lessons/presentation/widgets/item_category_widget.dart`
- **Video resizer:** `package:wordup_app/src/features/wordup/lessons/presentation/widgets/lesson_header_video_resizer.dartr`
- **Video header:** `package:wordup_app/src/features/wordup/lessons/presentation/widgets/question_video_header_widget.dart`

**Data Models:**
- **Lessons model:** `LessonsModel`
- **Question model:** `LessonQuestionModel`
- **Answer section:** `lessons_answer_section`

**Functions:**
- **Get questions:** `getLessonQuestions`, `getLessonsQuestions`
- **Complete lesson:** `completeLesson`
- **Add answer:** `lessonAnswerAdd`, `lessonQuestionAdd`
- **Calculate first incomplete:** `calcualtefirstIncompleteLesson`
- **Find first incomplete:** `_findFirstIncompleteLesson@2410123640`
- **Give points:** `giveUserLessonsPoints`
- **Unlocked lessons:** `UnlockedLessonIds`

**Video Player:**
- **Plugin:** `video_player_android` (Flutter video player plugin)
- **MIME type:** `application/vnd.hhe.lesson-player`
- **Video player:** `VideoPlayer`, `VideoPlayerController`
- **Video data:** `sendVideoData(player)` with video_id and currentTime

### What It Contains
- Listen practice widget
- Translation question widget
- Answer questions page with progress tracking
- Category selection widget
- Video header and resizer components
- Question-answer gameplay system
- Lesson completion tracking
- Points system for lessons
- Video playback with lesson-specific MIME type

### Logic Behind It

**Video Playback:**
- Uses `video_player_android` Flutter plugin
- Custom MIME type: `application/vnd.hhe.lesson-player`
- Video resizer widget for adjusting video display
- Video header widget for lesson video presentation
- Video data tracking: video_id, currentTime, loadedFraction
- Videos likely hosted on server and streamed via network

**Gameplay Method (Chapter):**
- Structured lesson flow with question-answer format
- Lessons organized by difficulty (calcualtefirstIncompleteLesson)
- Multiple question types: listening, translation, answering
- Progress tracking (answer_quetsion_progress_widget)
- Points system (giveUserLessonsPoints) for gamification
- Lesson completion tracking (completeLesson)
- Unlocked lesson IDs for progression

**Speaking Part:**
- Listen widget for listening practice
- Audio recording permissions (RECORD_AUDIO, AUDIO_CAPTURE)
- Likely uses device TTS for pronunciation (shared with other features)
- May use speech recognition for speaking practice
- Answer section (lessons_answer_section) for user responses

**Lesson Structure:**
- Beginner-friendly lessons with step-by-step approach
- Category-based organization (item_category_widget)
- First lesson feature discovery for new users
- Lesson cards for display (lessonsCard, _buildLessonCard)
- Home widget integration (HomeLessonsWidget)

---

## UI Section: Word Lists

### Related Files

**Controllers:**
- **New list controller:** `package:wordup_app/src/features/shared/word_list/presentation/controllers/new_custom_list_controller.dart`
- **Add word controller:** `package:wordup_app/src/features/shared/word_list/presentation/controllers/add_word_custom_list_controller.dart`
- **Edit controller:** `package:wordup_app/src/features/shared/word_list/presentation/controllers/edit_custom_list_controller.dart`
- **Import controller:** `ImportWordListController`

**Pages:**
- **My word list page:** `package:wordup_app/src/features/shared/word_list/presentation/pages/my_word_list_page.dart`
- **New custom list page:** `package:wordup_app/src/features/shared/word_list/presentation/pages/new_custom_list_page.dart`
- **Full word list page:** `package:wordup_app/src/features/shared/word_list/presentation/pages/full_word_list_page.dartr`

**Widgets:**
- **Search widget:** `MyWordListSearchWidget`, `FullWordListSearchWidget`
- **Home widget:** `HomeWordListWidget`
- **Sort dialog:** `package:wordup_app/src/features/shared/word_list/presentation/widgets/full_word_list_sort_dialog_widget.dartr`
- **List item:** `package:wordup_app/src/features/shared/word_list/presentation/widgets/new_custom_list_item_widget.dart`

**Data Models:**
- **Word list model:** `WordListModel`
- **Word list type:** `WordListType`, `FullWordListType`
- **Service:** `WordListServiceImpl.r`
- **Functions:** `_saveWordList@2382387682`, `_buildWordListItem@2866028627`

**Storage:**
- **Hive database:** `UserStorageHive` (Hive NoSQL database)
- **Box storage:** Hive boxes for word list data
- **SQLite database:** Main words database (my_wordup_v2.db)

**Premium/Pro Content:**
- **Pro check:** `IsPro`
- **Pro message:** "Pro gives you unlimited access to keep improving without breaks."
- **Shared lists:** "Get Pro to access shared lists!"
- **Membership model:** `package:wordup_app/src/features/shared/membership/data/models/product.dart`
- **Get Pro button:** `package:wordup_app/src/features/shared/drawer/presentation/widgets/home_drawer_get_pro_button.dart`

### What It Contains
- Custom word list creation
- Word list import functionality
- Sorting and organization of word lists
- Search functionality for word lists
- Home widget for word list access
- Premium/pro content (shared lists)
- Word list type categorization

### Logic Behind It

**Storage Method:**
- **Primary storage:** Hive NoSQL database (UserStorageHive)
- **Hive boxes:** Word lists stored in Hive boxes (key-value storage)
- **Words database:** SQLite database (my_wordup_v2.db) for word data
- **Hybrid approach:** Hive for user lists, SQLite for vocabulary data
- **Local-first:** Word lists stored locally on device

**Vocabulary Storage:**
- **Word data:** SQLite database (my_wordup_v2.db) with words table
- **Word fields:** wordId, rank, text, meaning, phonetics, learnStateInt
- **5.9MB database:** Contains vocabulary data embedded in app
- **Server sync:** Additional vocabulary may sync from server

**Premium/Pro Content:**
- **Shared lists:** Require Pro subscription ("Get Pro to access shared lists!")
- **Pro features:** Unlimited access, shared lists
- **Membership tracking:** subscriptionDate, IsPro flag
- **Product model:** Product data for subscription management
- **Database location:** Premium lists likely stored in same Hive database with Pro flag

**Database Structure:**
- **Hive boxes:** Key-value storage for word lists
  - UserStorageHive for user data
  - Separate boxes for different data types
  - NoSQL structure (not relational)
- **SQLite words table:** Relational database for vocabulary
  - wordId (primary key)
  - text (word)
  - primaryMeaning (definition)
  - britishPhonetic, americanPhonetic
  - learnStateInt (progress tracking)

**Word List Types:**
- **Custom lists:** User-created word lists
- **Full lists:** Complete vocabulary lists
- **Shared lists:** Premium content (Pro required)
- **Import lists:** Imported from external sources

**Storage Location:**
- **Local device:** All word lists stored locally
- **Server sync:** May sync user progress and premium lists
- **Offline access:** Word lists available offline (local storage)

---

## UI Section: Scenarios

### Related Files
- **Service:** `package:wordup_app/src/features/shared/scenarios/data/services/scenarios_service.dart`
- **Challenges page:** `package:wordup_app/src/features/shared/scenarios/presentation/pages/scenarios_challenges_page.dart`
- **Outstanding widget:** `package:wordup_app/src/features/shared/scenarios/presentation/widgets/outstanding_scenarios.dart`
- **Header widget:** `package:wordup_app/src/features/shared/scenarios/presentation/widgets/challenge_chat_header_area.dart`
- **Home card:** `package:wordup_app/src/features/wordup/home/presentation/widgets/scenarios/home_scenarios_card_widget.dart`
- **Route:** `/scenarios_map` (string reference)
- **Word list widget:** `package:wordup_app/src/features/shared/scenarios/presentation/widgets/animated_words_list.dart`
- **Word chip:** `package:wordup_app/src/features/shared/scenarios/presentation/widgets/challenge_word_chip/challenge_word_chip.dart`
- **Word identifiers:** `scenarios_word`, `scenarios-word`

### Shared Word Database (Across All Sections)

**Shared Services:**
- **Words service:** `package:wordup_app/src/features/shared/words/data/services/word_service.dartr`
- **Database helper:** `package:wordup_app/src/features/shared/words/data/services/database_helper.dart`
- **DB isolate:** `package:wordup_app/src/features/shared/words/data/services/db_isolate.dart`
- **Word model:** `package:wordup_app/src/features/shared/words/data/models/word_model.dart`
- **Bundle loader:** `package:wordup_app/src/features/shared/words/data/services/bundle_loader.dart`

**Database Tables (Shared):**

**1. Words Table:**
```sql
CREATE TABLE words (
    wordId INTEGER PRIMARY KEY,
    rank INTEGER,
    personalRank INTEGER,
    text TEXT COLLATE NOCASE,
    otherForms TEXT COLLATE NOCASE,
    primaryMeaning TEXT COLLATE NOCASE,
    primarySenseId TEXT COLLATE NOCASE,
    type INTEGER,
    britishPhonetic TEXT,
    americanPhonetic TEXT,
    learnStateInt INTEGER DEFAULT 2
)
CREATE INDEX IF NOT EXISTS idx_words_wordId ON words(wordId)
```

**2. WordLookup Table:**
```sql
CREATE TABLE WordLookup (
    word_id INTEGER NOT NULL PRIMARY KEY,
    lookups TEXT
)
```

**SQL Queries (Shared):**
- `SELECT wordId, learnStateInt FROM words`
- `WHERE wordId = ?` (used by multiple sections)
- `insert or replace into WordLookup (word_id, lookups) values (?, ?)`
- `select lookups from WordLookup where word_id = ? limit 1`

### What It Contains
- Scenarios data service
- Scenarios challenges page
- Outstanding scenarios widget
- Challenge chat header
- Home scenarios card widget
- Scenarios map route
- Animated words list widget
- Challenge word chip widget

### Logic Behind It

**Database Sharing:**
- **Scenarios** uses the same `words` table as Word Lists and Lessons
- **Word ID system:** All sections use `wordId` as primary key
- **Learn state tracking:** `learnStateInt` field shared across sections
- **Word lookup tracking:** `WordLookup` table tracks which words have been looked up

**Section Differences:**
- **Same database:** All sections query the same `words` table
- **Different presentation:** Each section displays words differently
- **Different tracking:** 
  - Word Lists: Custom lists in Hive
  - Lessons: Lesson completion tracking
  - Scenarios: Challenge-based word usage
  - Reviews: Spaced repetition using `learnStateInt`

**Word Data Format:**
- **Primary key:** `wordId` (INTEGER)
- **Word text:** `text` (TEXT, case-insensitive)
- **Meaning:** `primaryMeaning` (TEXT, case-insensitive)
- **Phonetics:** `britishPhonetic`, `americanPhonetic` (TEXT)
- **Progress:** `learnStateInt` (INTEGER, default 2)
- **Word forms:** `otherForms` (TEXT, case-insensitive)
- **Ranking:** `rank`, `personalRank` (INTEGER)

**Shared Mechanisms:**
1. **WordsService** - Centralized word data access
2. **DatabaseHelper** - SQLite database operations
3. **DB Isolate** - Database access in separate isolate for performance
4. **WordModel** - Shared data model for word data
5. **Load functions:** `_loadWordData@2324448011`, `_loadCustomWordListData@2645367940`

**Scenarios-Specific:**
- Uses `scenarios_word` and `scenarios-word` identifiers
- Challenge word chip widget for word display
- Animated words list for visual presentation
- Integration with chat system for scenario-based practice

**Module integration:** Connected to the `zann_roleplay` module (roleplay scenarios)

---

## Shared Infrastructure

### Chat System
**Files:**
- `package:wordup_app/src/features/shared/chat/data/models/word_chat.dart`
- `package:wordup_app/src/features/shared/chat/presentation/widgets/chat_input_section.dart`
- `package:wordup_app/src/features/shared/chat/presentation/widgets/chat_header_avatar.dart`
- `package:wordup_app/src/features/shared/chat/data/models/base_chat_thread.dart`
- `package:wordup_app/src/features/shared/chat/presentation/mixins/chat_controller_message_saver.dart`

**Purpose:** Shared chat infrastructure used by multiple features (Lexi, Fantasy Chat, Scenarios)

### Zann Modules
**Verified modules:**
- `zann_celebchat` - Celebrity chat (Fantasy Chat)
- `zann_dictionary` - Dictionary functionality
- `zann_roleplay` - Roleplay scenarios
- `zann_vocabulary` - Vocabulary management (Knowledge Map)
- `zann_writing` - Writing practice

**Purpose:** Modular architecture separating different learning features

---

## Database Structure

### Verified Table
**File:** `my_wordup_v2.db` (5.9MB SQLite database)

**Table schema:**
```sql
CREATE TABLE words (
    wordId INTEGER PRIMARY KEY,
    rank INTEGER,
    personalRank INTEGER,
    text TEXT COLLATE NOCASE,
    otherForms TEXT COLLATE NOCASE,
    primaryMeaning TEXT COLLATE NOCASE,
    primarySenseId TEXT COLLATE NOCASE,
    type INTEGER,
    britishPhonetic TEXT,
    americanPhonetic TEXT,
    learnStateInt INTEGER DEFAULT 2
)
```

**Fields:**
- `wordId`: Unique identifier
- `rank`: Word frequency/ranking
- `personalRank`: User-specific ranking
- `text`: The word itself
- `otherForms`: Alternative word forms
- `primaryMeaning`: Main definition
- `primarySenseId`: Sense identifier
- `type`: Word type/category
- `britishPhonetic`: UK pronunciation
- `americanPhonetic`: US pronunciation
- `learnStateInt`: Learning progress state (likely for reviews)

---

## Technical Architecture

### Framework
- **Flutter** (Dart) - Main application framework
- **AOT Compilation** - Dart compiled to native machine code
- **GetX** - State management (inferred from GetX references in strings)
- **Modular Architecture** - Feature-based code organization

### Code Organization
```
wordup_app/
├── src/
│   ├── features/
│   │   ├── wordup/          # Main WordUp features
│   │   │   ├── chat/         # Lexi chat
│   │   │   ├── challenges/   # Reviews
│   │   │   ├── lessons/      # Lessons
│   │   │   └── home/         # Home page
│   │   └── shared/          # Shared components
│   │       ├── chat/         # Shared chat system
│   │       ├── scenarios/    # Scenarios
│   │       └── word_list/    # Word lists
│   └── zann_*/              # Zann modules
│       ├── celebchat/       # Fantasy Chat
│       ├── dictionary/      # Dictionary
│       ├── roleplay/        # Roleplay
│       ├── vocabulary/      # Knowledge Map
│       └── writing/         # Writing
```

---

## What Cannot Be Verified

### Implementation Details
- **Exact algorithms** for spaced repetition in reviews
- **AI/chat backend** API endpoints or models
- **Learning progress** calculation logic
- **Database queries** and relationships
- **State management** implementation details
- **Network calls** and data synchronization

### Reason
These details are in the compiled Dart bytecode which is not easily decompilable. Only file paths and string literals are accessible via the native library strings extraction.

---

## App Main Flow

### Overall Architecture

**Framework:** Flutter (Dart) with AOT compilation
**State Management:** GetX (inferred from strings)
**Database:** Hybrid - SQLite (vocabulary) + Hive (user data)
**Network:** Server-based AI/chat with local caching
**Modular Design:** Zann modules for specialized features

### Data Flow Architecture

```
User Action → UI Layer (Flutter Widgets)
         ↓
Controller Layer (Get Controllers)
         ↓
Service Layer (Business Logic)
         ↓
Data Layer (SQLite + Hive + Server APIs)
```

### Main Flow by Section

**1. App Launch**
```
MainActivity (Flutter entry)
    ↓
Flutter Engine Initialization
    ↓
Load UserStorageHive (user data)
    ↓
Load my_wordup_v2.db (vocabulary)
    ↓
Sync with https://sync.wrdp.app (if online)
    ↓
Display Home Page
```

**2. Knowledge Map Flow**
```
User taps word in Knowledge Map
    ↓
Query SQLite words table by wordId
    ↓
Fetch word: text, phonetics, meaning
    ↓
Call _fetchTranslation (API) for translations
    ↓
Call _loadImage (cached_network_image) for AI images
    ↓
Display word with all data
    ↓
User plays pronunciation (flutter_tts)
    ↓
Update learnStateInt in database
```

**3. Practice with Lexi Flow**

**Vocabulary Mode:**
```
User selects Vocabulary mode
    ↓
Navigate to /lexi_vocabulary
    ↓
Load LexiVocabularyPage
    ↓
Query words from SQLite
    ↓
Use LexiExplainParams for explanations
    ↓
Display word with definitions
    ↓
User provides answer
    ↓
Evaluate and update progress
```

**Writing Mode:**
```
User selects Writing mode
    ↓
Navigate to /lexi_writing
    ↓
Load LexiWritingPage with LexiWritingController
    ↓
Display writing prompt
    ↓
User writes response (chat_input_section)
    ↓
Submit to /lexi_writing_result
    ↓
Evaluate writing quality
    ↓
Update progress
```

**Speaking Mode:**
```
User selects Speaking mode
    ↓
Navigate to LexiSpeakingPage
    ↓
Call speechLexi (TTS for Lexi)
    ↓
User responds via speechByVoice (speech recognition)
    ↓
Evaluate pronunciation
    ↓
Update progress
```

**4. Fantasy Chat Flow**
```
User selects Fantasy Chat
    ↓
Load zann_celebchat module
    ↓
Initialize ChatControllerCelebChat
    ↓
Query CelebChatDatabase for chat threads
    ↓
Select celebrity character
    ↓
Send message via chat_input_section
    ↓
Call /api/generate (server AI)
    ↓
Cache response locally
    ↓
Display in chat interface
    ↓
Update CelebchatPoints (gamification)
```

**5. Lessons Flow**
```
User selects Lessons
    ↓
Load LessonsController
    ↓
Calculate first incomplete lesson
    ↓
Display lesson card
    ↓
User starts lesson
    ↓
Load lesson video (video_player_android)
    ↓
Play video with MIME: application/vnd.hhe.lesson-player
    ↓
Display question (listen_widget / translation_widget)
    ↓
User answers (answer_questions_page)
    ↓
Track progress (answer_quetsion_progress_widget)
    ↓
Complete lesson (completeLesson)
    ↓
Give points (giveUserLessonsPoints)
    ↓
Update UnlockedLessonIds
```

**6. Word Lists Flow**
```
User selects Word Lists
    ↓
Load WordListModel from UserStorageHive
    ↓
Display word lists (HomeWordListWidget)
    ↓
User creates custom list (new_custom_list_page)
    ↓
Call _saveWordList to Hive
    ↓
User adds words to list
    ↓
Query words from SQLite by wordId
    ↓
Add wordId to Hive box
    ↓
For shared lists: Check IsPro flag
    ↓
If not Pro: Show "Get Pro to access shared lists!"
    ↓
If Pro: Load shared lists from server
```

**7. Scenarios Flow**
```
User selects Scenarios
    ↓
Load scenarios_service
    ↓
Navigate to scenarios_challenges_page
    ↓
Display scenario cards
    ↓
User selects scenario
    ↓
Load scenario words (animated_words_list)
    ↓
Display challenge_word_chip
    ↓
User practices words in context
    ↓
Use chat system (challenge_chat_header_area)
    ↓
Query words from SQLite (shared database)
    ↓
Update WordLookup table
    ↓
Complete scenario
    ↓
Sync progress to server
```

### Shared Infrastructure Flow

**Word Data Access:**
```
Any section needs word data
    ↓
Call WordsService
    ↓
DatabaseHelper opens SQLite connection
    ↓
DB Isolate handles query in separate thread
    ↓
Query: SELECT * FROM words WHERE wordId = ?
    ↓
Return WordModel
    ↓
Display in section-specific UI
```

**Chat System Flow:**
```
User sends message
    ↓
ChatController handles message
    ↓
MessageSaver saves to local database
    ↓
Send to server API (/api/generate)
    ↓
Cache response
    ↓
Display in chat_input_section
```

**Sync Flow:**
```
Periodic sync triggered
    ↓
Call https://sync.wrdp.app
    ↓
Download updated word data
    ↓
Download user progress
    ↓
Upload local changes
    ↓
Update SQLite database
    ↓
Update Hive boxes
```

### Data Storage Summary

**SQLite (my_wordup_v2.db):**
- words table (vocabulary)
- WordLookup table (word lookups)
- Shared across all sections
- 5.9MB embedded in app

**Hive (UserStorageHive):**
- Word lists (user-created)
- User progress data
- Settings
- NoSQL key-value storage
- Local device storage

**Server APIs:**
- https://sync.wrdp.app (sync)
- https://friends.wrdp.app (friends)
- https://auth.wordupapp.co (auth)
- /api/generate (AI responses)
- Cached locally after first fetch

### User Progress Tracking

**Reviews:** learnStateInt field in words table
**Lessons:** completeLesson function, UnlockedLessonIds
**Lexi:** LexiDayStreakCounter
**Fantasy Chat:** CelebchatPoints
**Word Lists:** seenWordListr tracking
**Scenarios:** Challenge completion status

All progress synced to https://sync.wrdp.app for cross-device access.

---

## Critical Information for Building Similar Apps

### Backend Architecture

**Server-Side Components:**
- **Sync Server:** https://sync.wrdp.app - Handles data synchronization across devices
- **Friends Server:** https://friends.wrdp.app - Manages social features and leaderboards
- **Auth Server:** https://auth.wordupapp.co - Authentication and user management
- **AI Generation:** /api/generate - AI chat response generation (likely OpenAI or similar LLM)

**Sync Strategy:**
- Hybrid approach: Local SQLite + Hive for offline capability
- Periodic sync with server for cross-device access
- Cached images and translations for offline use
- User progress (reviews, lessons, streaks) synced in real-time

**Data Sync Flow:**
```
User Action → Local Storage (SQLite/Hive)
         ↓
Immediate UI Update
         ↓
Background Sync to Server
         ↓
Server Confirmation
         ↓
Update Local Storage (if conflict)
```

### Gamification Mechanics

**1. Reviews (Spaced Repetition):**
- **Tracking Field:** `learnStateInt` in words table
- **Likely Algorithm:** SuperMemo-2 or Anki-style spaced repetition
- **States:** New, Learning, Review, Mastered (inferred from learnStateInt values)
- **Trigger:** Based on time intervals and performance
- **Data Source:** Local SQLite database

**2. Lessons (Progression System):**
- **Progression:** calcualtefirstIncompleteLesson() for lesson flow
- **Unlocks:** UnlockedLessonIds for tracking completed lessons
- **Points:** giveUserLessonsPoints() for gamification
- **Completion Tracking:** completeLesson() marks lesson as done
- **Structure:** Hierarchical (beginner → intermediate → advanced)
- **Data Source:** Server API + local caching

**3. Lexi Practice (Streak System):**
- **Tracking:** LexiDayStreakCounter for daily practice consistency
- **Modes:** Vocabulary, Writing, Speaking
- **Writing Mode:** LexiWritingController with result tracking
- **Speaking Mode:** speechLexi (TTS output) + speechByVoice (speech recognition input)
- **Data Source:** Local SQLite + server AI for feedback

**4. Fantasy Chat (Points System):**
- **Points:** CelebchatPoints for engagement tracking
- **Reminder:** CelebchatReminderService for retention
- **AI:** Server-side AI responses (/api/generate)
- **Database:** Separate CelebChatDatabase for chat history
- **Data Source:** Server API + local caching

**5. Scenarios (Challenge System):**
- **Progress:** Challenge completion status
- **Words:** Animated words list for visual presentation
- **Context:** Real-world usage scenarios
- **Data Source:** Local SQLite (shared words table)

### Monetization Strategy

**Premium/Pro Features:**
- **Shared Word Lists:** Require Pro subscription
- **Unlimited Access:** "Pro gives you unlimited access to keep improving without breaks"
- **Membership Model:** Product model with subscriptionDate and IsPro flag
- **Subscription Check:** IsPro flag in Hive database
- **Billing:** Likely uses RevenueCat or similar (inferred from modern app patterns)

**Free Tier Limitations:**
- Limited shared list access
- Possible daily limits on AI interactions (inferred)
- Basic vocabulary database (5.9MB embedded)

### User Experience Flows

**New User Onboarding:**
1. App launch → Flutter Engine initialization
2. Load UserStorageHive (user data)
3. Load my_wordup_v2.db (vocabulary)
4. Display Home Page with widgets
5. Show onboarding for Knowledge Map
6. Guide user to first review or lesson

**Daily Learning Routine:**
1. Open app → Check sync status
2. Today's Reviews (spaced repetition)
3. Practice with Lexi (maintain streak)
4. Lessons (progression)
5. Word Lists (custom lists)
6. Scenarios (real-world practice)
7. Fantasy Chat (optional engagement)

**Word Learning Flow:**
```
User encounters word
    ↓
Tap word in Knowledge Map
    ↓
Fetch from SQLite: text, phonetics, meaning
    ↓
Call API for translations (if online)
    ↓
Load cached image (if available)
    ↓
Play pronunciation (flutter_tts)
    ↓
Update learnStateInt
    ↓
Sync progress to server
```

### Technical Considerations for Similar Apps

**1. Database Choice:**
- **SQLite:** For structured vocabulary data (relational)
- **Hive:** For user data, settings, word lists (NoSQL, fast)
- **Reason:** Hybrid approach balances structure and flexibility

**2. Offline-First Design:**
- Embed core vocabulary database (5.9MB)
- Cache images and translations locally
- Use cached_network_image for image caching
- Sync periodically when online
- Essential for language learning apps

**3. AI Integration:**
- Server-side AI for chat responses (cost-effective)
- On-device TTS for pronunciation (no network needed)
- Speech recognition for speaking practice
- VisionKit for image recognition (if needed)
- Balance between server and device capabilities

**4. State Management:**
- **GetX:** For reactive state management (inferred from strings)
- **Controllers:** Separate controllers for each feature (LexiWritingController, LessonsController, etc.)
- **Mixins:** For shared functionality (MessageSaver, CelebchatPointsMixin)
- **Repository Pattern:** For data access (WordListServiceImpl, CelebchatRepository)

**5. Modular Architecture:**
- **Zann Modules:** Separate features into modules (zann_vocabulary, zann_celebchat, zann_roleplay)
- **Shared Components:** Common UI components (chat_input_section, chat_header_avatar)
- **Feature-Based Organization:** src/features/wordup/, src/features/shared/, src/zann_*/
- **Benefits:** Easier maintenance, team collaboration, testing

**6. Performance Optimization:**
- **DB Isolate:** Database access in separate thread for performance
- **Bundle Loader:** Efficient asset loading
- **Lazy Loading:** Load words on-demand
- **Image Caching:** cached_network_image for images
- **Video Streaming:** Custom MIME type for lesson videos

**7. Cross-Platform Strategy:**
- **Flutter:** Single codebase for iOS and Android
- **AOT Compilation:** Native performance
- **Platform-Specific Plugins:** flutter_tts, video_player_android
- **Native Integration:** Platform channels for device features

### Critical Missing Information (Cannot Be Verified)

**Server-Side Implementation:**
- Exact AI model used for chat responses
- Spaced repetition algorithm parameters
- Lesson progression logic details
- Gamification reward calculation formulas
- User authentication flow details
- Subscription management implementation

**Business Logic:**
- How streak resets are calculated
- How points are awarded in lessons
- How Lexi evaluates writing/speaking
- How Fantasy Chat AI is configured
- How scenario challenges are generated

**Data Analytics:**
- User engagement metrics tracked
- Learning effectiveness measurements
- A/B testing implementation
- Personalization algorithms

**Reason:** These details require server access, API documentation, or deeper reverse engineering of compiled bytecode beyond static analysis.

---

## Comparison with Other Analyzed Apps

### WordBranch (com.english4formosa.www)
- **Data:** 104,004 words in SQLite (14.5MB) - Larger dataset
- **Approach:** Pre-loaded database, no server sync for vocabulary
- **Target:** Taiwan exam preparation (學測)
- **AI:** ML Kit barcode scanning (on-device)
- **Monetization:** Google Play Billing

### SnapWords (com.HappyPlanTech.SnapWords)
- **Data:** JSON flashcard files (multilingual)
- **Approach:** VisionKit for object recognition + AI translation
- **Target:** Photo-based vocabulary learning
- **AI:** Multiple AI providers (Gemini, OpenAI, Alibaba, ByteDance)
- **Monetization:** RevenueCat subscriptions
- **Platform:** iOS only

### EnglishWidget (com.cmoney.englishwidget)
- **Data:** Server-fetched (no local database)
- **Approach:** Server-based with gamification
- **Target:** Gamified vocabulary learning
- **AI:** Server-side (not specified)
- **Monetization:** Google Play Billing + VIP system
- **Platform:** Android only

### WordUp (wordupapp.co)
- **Data:** 5.9MB SQLite + server sync
- **Approach:** Hybrid offline-first with sync
- **Target:** Comprehensive vocabulary learning
- **AI:** Server-side AI chat + on-device TTS
- **Monetization:** Pro subscription (inferred)
- **Platform:** Flutter (cross-platform)

**Key Differentiator:** WordUp uses hybrid offline-first approach with server sync, while others are either fully local (WordBranch), fully server-based (EnglishWidget), or photo-focused (SnapWords).
